# Added detector source manifest — SynOD-Atlas manuscript v1.4

The five added continuous-score wrappers are source-faithful adaptations of PyOD **v3.6.6**, tag `v3.6.6`, target commit `3a71f47bb2cb9b7c8a09fc92e5c67510d7198b58`, under the upstream BSD 2-Clause license. Only training anomaly-score logic is retained; contamination-dependent thresholding and binary-label post-processing are intentionally excluded because SynOD-Atlas evaluates continuous scores by ROC-AUC and average precision.

| SynOD detector | Upstream file | Git blob SHA |
|---|---|---|
| HBOS | `pyod/models/hbos.py` | `042835a1954b9ed6b8468cd9ab4237cfb299d6e9` |
| COPOD | `pyod/models/copod.py` | `81f95aef7d8220765e147e5ef468e895a110c60e` |
| LODA | `pyod/models/loda.py` | `3e7fcbe25e3d16cb6d8648578b7bd757a20f1738` |
| iNNE | `pyod/models/inne.py` | `b673f3d00ff4263b30312ac92d1620b6be8d5583` |
| Sampling | `pyod/models/sampling.py` | `a3a207eb185a210a6d312206ebe246c02748944e` |
| License | `LICENSE` | `96752b2d8d126e754a23df2de084557b538ab8f1` |

The exact adapted code used for all 10,500 added core executions is `code/extra_detectors_pyod366.py`. CBLOF was screened but not admitted to manuscript v1.4 because its default small/large-cluster separation rule is undefined in part of the controlled grid, violating the complete-panel inclusion rule.

## Direct-equivalence audit added in v1.4

`PYOD_DIRECT_EQUIVALENCE_v1.4.csv` and `code/validate_pyod_equivalence_v13.py` compare the five released score adaptations directly with the installed upstream `pyod==3.6.6` classes. Across 60 detector-case-seed comparisons, the maximum absolute score difference is 0.0; all rank correlations equal 1.000 to reported precision. This turns wrapper fidelity from a source-provenance claim into an executable numerical check.

Historical upstream commit and blob identifiers are retained from the v1.3 source manifest; this turn re-executed package-level numerical equivalence against installed PyOD 3.6.6. The actual package license is bundled.
