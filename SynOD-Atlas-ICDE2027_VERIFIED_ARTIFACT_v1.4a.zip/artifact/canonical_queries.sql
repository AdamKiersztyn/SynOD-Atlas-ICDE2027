-- SynOD-Atlas v1.4 canonical Failure Cube workload

-- Q1: collapse onset and uncertainty for one detector
SELECT family, d, pi, detector, boundary50_point, ci025, ci975, defined_fraction
FROM boundaries_tau030
WHERE detector = 'pca'
ORDER BY family, d, pi;

-- Q2: mechanism-wise contrast for the near-equal-mean KMeans/OCSVM pair
SELECT a.family,
       AVG(a.q) AS kmeans_q,
       AVG(b.q) AS ocsvm_q,
       AVG(a.q) - AVG(b.q) AS signed_gap
FROM runs a JOIN runs b ON a.dataset_id=b.dataset_id
WHERE a.detector='kmeans' AND b.detector='ocsvm'
GROUP BY a.family
ORDER BY ABS(signed_gap) DESC;

-- Q3: factor cells with substantial cross-detector competence disagreement
SELECT family, d, pi, stress,
       MIN(competence_probability) AS min_competence,
       MAX(competence_probability) AS max_competence
FROM competence_tau030
GROUP BY family, d, pi, stress
HAVING max_competence - min_competence >= 0.60
ORDER BY (max_competence-min_competence) DESC;

-- Q4: execution-completeness audit; expected result is zero rows
SELECT dataset_id, COUNT(*) AS n_detector_runs
FROM runs
GROUP BY dataset_id
HAVING n_detector_runs <> 13;

-- Q5: boundary uncertainty by mechanism and detector
SELECT family, detector,
       AVG(ci_width) AS mean_ci_width,
       AVG(defined_fraction) AS bootstrap_defined_fraction
FROM boundaries_tau030
GROUP BY family, detector
ORDER BY mean_ci_width DESC;
