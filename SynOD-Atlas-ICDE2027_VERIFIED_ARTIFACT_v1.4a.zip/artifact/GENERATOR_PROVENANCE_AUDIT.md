# SynOD-Atlas v2.1 — Generator Provenance Audit

## Executive finding
The calibrated Pilot-10 used for manuscript v0.3 is **not** a faithful continuous extension of the original SynOD-Atlas v1.4 generator. Five families (F02, F03, F08, F09, F10) changed the data-generating mechanism materially; F04 and F05 retained the broad semantic label but altered geometry and parameter trajectories substantially. F01 was structurally compatible, while F06/F07 were closest to the v1.4 Core fixed-k mechanism.

Accordingly, v0.3 empirical numbers must be treated as provisional and replaced by results from an anchor-preserving generator.

## Provenance validation
- `SynOD-Atlas-GitHub-ready-v1.4.zip` SHA-256: `caada01edadf5a9fa1f61adc5468b9f8977963190e0fbfba764c76f72d3e415e` — exact match to the public-release manifest.
- Original release tests: 8/8 passed locally.
- The included F06 sample is regenerated to numerical precision from the original generator.
- A v2 anchor wrapper reproduces all 30 tested family × {medium, hard, extreme} anchors bit-for-bit for a representative configuration.

## Family-by-family audit

| Family | v1.4 Core mechanism | Pilot-10 v0.3 mechanism | Verdict | v2.1 action |
|---|---|---|---|---|
| F01 | isotropic normal vs mean-shift anomalies; delta=4.0 medium, 2.5 hard | same mean-shift idea, different stress range | compatible but unanchored | retain original formula; exact v1.4 anchors |
| F02 | block-correlated normals; selected blocks reversed/noised in anomalies | Gaussian covariance matrices with different rho only | **incompatible** | restore block-corruption generator; interpolate physical corruption parameters |
| F03 | 3-mode imbalanced GMM; anomaly bridge between two legal modes | 2-mode axis-aligned mixture with uniform bridge coefficients | **incompatible** | restore 3-mode bridge; medium/hard exact anchors; continue bridge ambiguity physically |
| F04 | dense+sparse legal modes; anomalies near sparse mode | related density setup but different mixture weights, sigmas and geometry | materially modified | restore v1.4 medium/hard; extend by decreasing offset and matching sparse density |
| F05 | compact anomaly cluster approaching normal support | compact anomaly cluster, much wider range and reversed sigma trend | related but unanchored | restore v1.4 trajectory and anchors |
| F06 | fixed-k subspace shift in Core; per-feature delta 3.0→2.5 | fixed-k shift expressed as total L2 shift | structurally compatible | use original fixed-k generator and delta trajectory |
| F07 | fixed-k informative dimensions plus Gaussian irrelevant features | same broad fixed-k masking idea | structurally compatible | use original generator exactly at anchors |
| F08 | sinusoidal 1D manifold randomly embedded in d; off-manifold shift | 2D circle in first coordinates with radial anomalies | **incompatible** | restore embedded sinusoidal manifold |
| F09 | uniform d-ball; anomalies strictly outside support boundary | anomaly radii could cross inside the support | **incompatible** | restore strict boundary-violation mechanism |
| F10 | rare legal cluster and anomaly cluster in distinct random directions | rare and anomalous cluster placed on the same direction | **incompatible** | restore distinct-direction rare-normal mechanism |

## Stress-coordinate design rule for v2.1
The normalized coordinate `s∈[0,1]` is a **family-specific structural stress coordinate**, not an empirical difficulty score. It is defined exclusively from generator parameters before detector evaluation. The v1.4 Core `medium` and `hard` configurations are exact anchors. Intermediate points interpolate physical parameters; extensions beyond the Core continue the same anomaly mechanism toward greater structural ambiguity. Detector performance is never used to choose a stress value.

F03 and F04 require special treatment because legacy `easy/extreme` labels do not form a physically or empirically ordered trajectory. Their v2.1 paths therefore preserve the exact medium/hard Core anchors while extending the same mechanism directly, rather than inheriting nonmonotone legacy labels.

## Consequence for manuscript claims
All v0.3 Pilot-10 statistics (factorial effects, surface distances, boundary widths, competence islands, Failure Cube contents) are superseded until recomputed on v2.1. The conceptual framework remains valid; the empirical values must be regenerated.
