# Submission artifact and validation notes

This archive accompanies *From Aggregate Scores to Competence Geometry in Unsupervised Outlier Detection*. The benchmark is named SynOD-Atlas; its name does not appear in the manuscript title.

## Audited identity

- Synthetic tasks: **2,100**.
- Detectors: **13**; frozen core executions: **27,300**.
- Additional sample-size runs: **6,552**.
- Additional hyperparameter runs: **1,008**.
- External frozen panel: **31 datasets by 24 detectors**.

## Quick verification

From this `artifact` directory using Python 3.12 and `code/requirements_v21a.txt`:

```bash
python code/verify_release.py --artifact-root .
python code/smoke_verify_v10.py --artifact-root .
python code/reproduce_paper.py --artifact-root . --output reproduced
python code/verify_release.py --artifact-root . --reproduced reproduced
sha256sum -c SHA256SUMS.txt
```

The table reproduction uses frozen detector scores; full independent reruns are more computationally demanding. `LOCAL_VERIFICATION_2026-10-21.json` describes exactly what was verified in this preparation session.

The external panel can only be reproduced at the released derived-matrix level: raw upstream source URLs, permissions and preprocessing are not completely recoverable for every real-world dataset. The synthetic-to-real exact geometric transfer test is null; do not claim positive transfer.

The existing `code/` source and the third-party license notices are carried forward unchanged. Generated Python bytecode has been removed.
