# External panel scope

Historical input: `dataset_difficulty_analysis.xlsx`.
Input SHA-256: `9d2dc71849ed3d8174b3e1105cffaad48b4713b837ca12ef3d76e7ca0d6a851e`.
The v1.3 export contained 31 tasks and 25 profiles. This release removes the ECOD column without changing retained values; the active matrix has 24 profiles. Other excluded project methods were absent.

The task manifest and historical missing-provenance table are preserved as evidence of the limitation. Their raw-source fields are not retrospectively filled by guessing dataset identities. Published external comparisons and the exact six-detector transfer test can be reconstructed from the active CSV. They cannot establish full raw-experiment reproducibility.
The archived spreadsheet is excluded from this release to prevent obsolete 25-method summaries from being mistaken for active results.
