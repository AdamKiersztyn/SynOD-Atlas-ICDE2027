# Active method policy

Excluded from every active benchmark panel: ECOD, FEOD, EFROD, RCOD, FROD.
The synthetic panel contains kNN, average-kNN, LOF, Isolation Forest, PCA residual, OCSVM, KMeans distance, GMM density, HBOS, COPOD, LODA, iNNE and Sampling.
Only public-source methods with auditable score semantics and complete execution coverage are admitted. This exclusion list is a project selection constraint, not a statement that every excluded method lacks public source.
Any panel change requires a new version and recomputation of all dependent summaries.
