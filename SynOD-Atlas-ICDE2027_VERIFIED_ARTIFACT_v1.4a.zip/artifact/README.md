# SynOD-Atlas — ICDE manuscript v1.4 artifact

The active panel excludes ECOD, FEOD, EFROD, RCOD and FROD. There are 2,100 synthetic tasks and 27,300 runs of 13 public-source detectors. The external derived panel has 31 tasks and 24 detector profiles. Historical generator version 1.4 must not be confused with this manuscript release number.

## Quick reproduction (from this directory)

Use Python 3.12 and an isolated environment:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r code/requirements_v21a.txt
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python code/verify_release.py --artifact-root .
python code/smoke_verify_v10.py --artifact-root .
python code/reproduce_paper.py --artifact-root . --output reproduced
python code/verify_release.py --artifact-root . --reproduced reproduced
python code/build_failure_cube_v10.py --artifact-root . --output reproduced/failure_cube.sqlite
```

The table-reproduction path uses frozen execution scores, including the full 10,000-permutation inferential analysis. It does not rerun every detector on every dataset. The retained `v10`/`v11` filenames identify script lineage, not the active detector count.

## Raw-generation routes

```bash
python code/run_core_v10.py --output raw_core
python code/run_sample_size_extension_v11.py --n 250 --out raw_sample_size
# Repeat the sample command for n = 500, 1000, 2000, 5000, 10000.
python code/reproduce_hyperparameters.py --artifact-root . --output raw_hyperparameters --regenerate
```

Full raw runs are substantially more expensive than table reproduction. No runtime guarantee is made. Sample-size runs checkpoint per task. The core runner writes family-level checkpoints but does not resume automatically.

Optional direct comparison of the five adapted PyOD scorers:

```bash
python -m pip install -r code/requirements_equivalence_v13.txt
python code/validate_pyod_equivalence_v13.py
```

## Frozen scientific inputs
- `v21a_datasets_metadata.csv`: 2,100 keys and physical generator coordinates.
- `core_metrics.csv`: 27,300 retained executions; no excluded method.
- `sample_size_extension_v11/sample_size_n250_to_10000_all_metrics.csv`: 6,552 executions.
- `hyperparameter_sensitivity/hyperparam_all_metrics.csv`: 1,008 executions.
- `real31_detector_profiles.csv`: 31 × 24 historical derived values, with missing cells preserved.
- `failure_cube.sqlite`, `canonical_queries.sql`: relational claims, integrity and provenance.
- `reproduced_analysis_v10/`, `reproduced_analysis_v11/`, `hyperparameter_sensitivity/`: current reference analyses, despite inherited directory names.

## Scope of reproducibility
Synthetic generation, scoring, and analyses have source-level reproduction routes. External results are reproducible from the released derived matrix only: the historical workbook did not retain complete raw URL, license, label and preprocessing lineage for every task. This release does not claim reconstruction of those raw experiments. The original workbook is not redistributed in the active package; a provenance note records the input hash and extraction scope.

Bootstrap code uses aligned seed trajectories with fixed seed 20260919; boundary confidence intervals are conditional on a defined crossing and accompanied by its bootstrap frequency. No synthetic-to-real performance guarantee is claimed.

Original SynOD code retains `code/LICENSE_v1.4`; adapted PyOD logic retains its upstream notice in `code/LICENSE_PYOD`. The PyOD source manifest describes provenance. Runtime and source inventory are recorded separately from scientific scores.

Numerical normalization uses the realized anomaly proportion floor(n*pi)/n, with the historical 1e-12 denominator stabilizer; the scientific formula omits that numerical epsilon.
