from pathlib import Path
import argparse,time
import numpy as np,pandas as pd
from generators_v21 import generate_v21,STRESSES
from extra_detectors_pyod366 import EXTRA_DETECTORS,run_extra_detector
from synod_atlas.evaluation import compute_metrics

def main(family,artifact):
    root=Path(artifact); out=root/'extra6_by_family'; out.mkdir(exist_ok=True)
    old=pd.read_csv(root/'v21a_metrics.csv'); mp=(old[old.family.eq(family)][['family','d','n','pi','stress','seed','dataset_id']].drop_duplicates().assign(stress_key=lambda x:x.stress.round(8)).set_index(['family','d','n','pi','stress_key','seed']).dataset_id.to_dict())
    p=out/f'{family}_extra6_metrics.csv'; rows=[]; done=set(); t0=time.time()
    if p.exists() and p.stat().st_size>10:
        try:
            olddf=pd.read_csv(p); rows=olddf.to_dict('records'); done={(int(r.d),round(float(r.pi),8),round(float(r.stress),8),int(r.seed),str(r.detector)) for r in olddf.itertuples()}
        except Exception:
            rows=[]; done=set()
    for d in [10,50,100]:
      for pi in [.05,.10]:
       for h in STRESSES:
        for seed in [1,2,3,4,5]:
         need=[det for det in EXTRA_DETECTORS if (d,round(float(pi),8),round(float(h),8),seed,det) not in done]
         if not need: continue
         X,y,_=generate_v21(family,500,d,pi,h,seed)
         did=mp[(family,d,500,pi,round(float(h),8),seed)]
         for det in need:
          st=time.perf_counter()
          try:
           sc=np.asarray(run_extra_detector(det,X,random_state=seed),float); z=compute_metrics(y,sc); status='ok';err=''
          except Exception as e:
           z={'roc_auc':np.nan,'average_precision':np.nan,'rank_quality':np.nan};status='error';err=repr(e)
          rows.append(dict(dataset_id=did,family=family,d=d,n=500,pi=pi,stress=h,seed=seed,detector=det,status=status,runtime_sec=time.perf_counter()-st,error=err,roc_auc=z['roc_auc'],average_precision=z['average_precision'],q=z['rank_quality']))
         tmp=p.with_suffix('.tmp'); pd.DataFrame(rows).to_csv(tmp,index=False); tmp.replace(p)
       print(family,d,pi,len(rows),flush=True)
    df=pd.DataFrame(rows); tmp=p.with_suffix('.tmp'); df.to_csv(tmp,index=False); tmp.replace(p); print(family,len(df),(df.status!='ok').sum(),time.time()-t0,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--family',required=True);ap.add_argument('--artifact',required=True);a=ap.parse_args();main(a.family,a.artifact)
