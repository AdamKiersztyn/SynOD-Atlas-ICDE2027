#!/usr/bin/env python3
"""Direct numerical equivalence audit for the five PyOD-derived SynOD wrappers.

Requires pyod==3.6.6. Compares the released source-faithful continuous-score
adaptations against the upstream PyOD classes on four deterministic data regimes
and three random seeds. The test intentionally compares training anomaly scores;
contamination-dependent threshold/label post-processing is outside SynOD-Atlas.
"""
from __future__ import annotations
import csv
import importlib.metadata as md
import sys
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from extra_detectors_pyod366 import (
    hbos_score, copod_score, loda_score, inne_score, sampling_score
)

from pyod.models.hbos import HBOS
from pyod.models.copod import COPOD
from pyod.models.loda import LODA
from pyod.models.inne import INNE
from pyod.models.sampling import Sampling

REF = {
    "hbos": lambda X, seed: hbos_score(X),
    "copod": lambda X, seed: copod_score(X),
    "loda": lambda X, seed: loda_score(X, random_state=seed),
    "inne": lambda X, seed: inne_score(X, random_state=seed),
    "sampling": lambda X, seed: sampling_score(X, random_state=seed),
}
UP = {
    "hbos": lambda seed: HBOS(),
    "copod": lambda seed: COPOD(n_jobs=1),
    "loda": lambda seed: LODA(random_state=seed),
    "inne": lambda seed: INNE(random_state=seed),
    "sampling": lambda seed: Sampling(random_state=seed),
}

def make_case(case: int) -> np.ndarray:
    rng = np.random.RandomState(100 + case)
    if case == 0:
        return rng.normal(size=(240, 10))
    if case == 1:
        return np.r_[rng.normal(size=(210, 10)), rng.normal(3, .7, size=(30, 10))]
    if case == 2:
        return np.round(rng.normal(size=(240, 10)), 1)  # ties stress score semantics
    return np.c_[rng.standard_t(3, size=(240, 5)), rng.normal(size=(240, 5))]

def main() -> None:
    if md.version("pyod") != "3.6.6":
        raise RuntimeError(f"Expected pyod==3.6.6, found {md.version('pyod')}")
    rows = []
    for case in range(4):
        X = make_case(case)
        for seed in (1, 7, 23):
            for name in REF:
                syn = np.asarray(REF[name](X, seed), float)
                model = UP[name](seed)
                model.fit(X)
                upstream = np.asarray(model.decision_scores_, float)
                rows.append({
                    "case": case,
                    "seed": seed,
                    "detector": name,
                    "max_abs": float(np.max(np.abs(syn-upstream))),
                    "mae": float(np.mean(np.abs(syn-upstream))),
                    "spearman": float(spearmanr(syn, upstream).statistic),
                })
    out = HERE.parent / "PYOD_DIRECT_EQUIVALENCE_v1.4.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    assert max(r["max_abs"] for r in rows) < 1e-12, "Score equivalence failed"
    print(f"pyod={md.version('pyod')} checks={len(rows)} "
          f"max_abs={max(r['max_abs'] for r in rows):.17g} "
          f"min_spearman={min(r['spearman'] for r in rows):.17g}")

if __name__ == "__main__":
    main()
