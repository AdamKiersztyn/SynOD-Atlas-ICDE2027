from __future__ import annotations
import argparse
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np,pandas as pd

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--analysis',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    ana=Path(a.analysis);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    E=pd.read_csv(ana/'sample_size_effects_extended.csv').sort_values('n')
    S=pd.read_csv(ana/'sample_size_surface_stability_extended.csv')
    n=E.n.to_numpy(int);ratio=E.interaction_to_detector_ratio.to_numpy(float)
    rho=[];mae=[]
    for x,y in zip(n[:-1],n[1:]):
        r=S[(S.n_a==x)&(S.n_b==y)].iloc[0];rho.append(float(r.cell_q_spearman));mae.append(float(r.cell_q_mae))
    y_offsets=[22,-31,22,-31,22]
    fig,ax=plt.subplots(figsize=(4.5,3.1));ax.plot(n,ratio,marker='o',linewidth=1.7,markersize=4.5)
    ax.set_xscale('log');ax.set_xticks(n);ax.set_xticklabels(['250','500','1k','2k','5k','10k']);ax.set_xlabel('Sample size $n$');ax.set_ylabel(r'$\eta_p^2(A{:}M)\,/\,\eta_p^2(A)$');ax.set_ylim(1.55,2.94);ax.grid(True,axis='y',alpha=0.22)
    ax.annotate(f'{ratio[0]:.2f}',(n[0],ratio[0]),xytext=(0,7),textcoords='offset points',ha='center',fontsize=8.5)
    ax.annotate(f'{ratio[-1]:.2f}',(n[-1],ratio[-1]),xytext=(-3,-12),textcoords='offset points',ha='right',fontsize=8.5)
    for i in range(len(rho)):
        xmid=np.sqrt(n[i]*n[i+1]);ymid=(ratio[i]+ratio[i+1])/2
        ax.annotate(rf'$\rho$={rho[i]:.3f}'+'\n'+f'MAE={mae[i]:.4f}',(xmid,ymid),xytext=(0,y_offsets[i]),textcoords='offset points',ha='center',va='center',fontsize=7.5)
    fig.tight_layout(pad=0.55);fig.savefig(out/'fig_sample_size_trajectory.png',dpi=300,bbox_inches='tight');plt.close(fig)
if __name__=='__main__':main()
