from pathlib import Path
import argparse,itertools
import numpy as np,pandas as pd
from scipy.stats import spearmanr

def first_loss_vec(stress,C,gamma=.5):
    B=C.shape[1];out=np.full(B,np.nan);found=np.zeros(B,bool)
    for i in range(len(stress)-1):
        mask=(~found)&(C[i]>=gamma)&(C[i+1]<gamma)
        if not np.any(mask): continue
        den=C[i+1,mask]-C[i,mask]
        vals=np.where(den==0,(stress[i]+stress[i+1])/2,stress[i]+(gamma-C[i,mask])*(stress[i+1]-stress[i])/den)
        out[mask]=vals;found[mask]=True
    return out

def boundary_bootstrap(metrics,tau=.30,gamma=.5,B=1000,seed=20260919):
    rng=np.random.default_rng(seed);rows=[];idx=rng.integers(0,5,size=(B,5));keys=['family','d','pi','detector']
    for key,g in metrics.groupby(keys,sort=True):
        piv=g.pivot_table(index='stress',columns='seed',values='q').sort_index();stress=piv.index.to_numpy(float);Q=piv.to_numpy(float)
        point=first_loss_vec(stress,(Q>=tau).mean(axis=1)[:,None],gamma)[0]
        C=(Q[:,idx]>=tau).mean(axis=2);vals=first_loss_vec(stress,C,gamma);vals=vals[np.isfinite(vals)]
        if len(vals): med=float(np.median(vals));lo=float(np.quantile(vals,.025));hi=float(np.quantile(vals,.975));sd=float(vals.std(ddof=1)) if len(vals)>1 else 0.
        else: med=lo=hi=sd=np.nan
        rows.append([*key,tau,point,med,lo,hi,len(vals)/B,sd,hi-lo if np.isfinite(hi) else np.nan])
    return pd.DataFrame(rows,columns=keys+['tau','boundary50_point','bootstrap_median','ci025','ci975','defined_fraction','bootstrap_sd','ci_width'])

def pair_matrix(df,metric):
    dets=list(df.columns);M=np.zeros((len(dets),len(dets)))
    for i,a in enumerate(dets):
        for j,b in enumerate(dets):
            A=df[a].to_numpy(float);B=df[b].to_numpy(float);mask=np.isfinite(A)&np.isfinite(B);A=A[mask];B=B[mask]
            if metric=='raw_mad':v=np.mean(np.abs(A-B))
            elif metric=='centered_mad':v=np.mean(np.abs((A-A.mean())-(B-B.mean())))
            elif metric=='z_rmse':
                za=(A-A.mean())/A.std(ddof=1);zb=(B-B.mean())/B.std(ddof=1);v=np.sqrt(np.mean((za-zb)**2))
            else:v=1-spearmanr(A,B).statistic
            M[i,j]=v
    return M

def mantel_exact(A,B):
    iu=np.triu_indices_from(A,k=1);av=A[iu];obs=spearmanr(av,B[iu]).statistic;vals=[]
    for perm in itertools.permutations(range(A.shape[0])):vals.append(spearmanr(av,B[np.ix_(perm,perm)][iu]).statistic)
    vals=np.asarray(vals);return obs,float(np.mean(vals>=obs-1e-15)),float(np.mean(np.abs(vals)>=abs(obs)-1e-15))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--metrics',required=True);ap.add_argument('--real',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    m=pd.read_csv(a.metrics);bb=boundary_bootstrap(m);bb.to_csv(out/'boundary_bootstrap_tau030.csv',index=False)
    r=pd.read_csv(a.real);dets=[c for c in r.columns if c!='Dataset'];pairs=[]
    for i,xn in enumerate(dets):
        for yn in dets[i+1:]:
            x=r[xn].to_numpy(float);y=r[yn].to_numpy(float);mask=np.isfinite(x)&np.isfinite(y);x=x[mask];y=y[mask]
            if len(x)<10:continue
            pairs.append([xn,yn,len(x),x.mean(),y.mean(),abs(x.mean()-y.mean()),spearmanr(x,y).statistic,np.mean(np.abs((x-x.mean())-(y-y.mean())))])
    rp=pd.DataFrame(pairs,columns=['detector_a','detector_b','n_real_datasets','mean_a','mean_b','abs_mean_gap','profile_spearman','centered_mad']);rp.to_csv(out/'real25_pairwise_profile_geometry.csv',index=False)
    rp[(rp.abs_mean_gap<=.015)&(rp.n_real_datasets>=25)].sort_values('profile_spearman').to_csv(out/'real25_near_equal_eps015.csv',index=False)
    cell=m.groupby(['family','d','pi','stress','detector'],as_index=False).q.mean();shared=['knn','lof','iforest','pca','ocsvm','gmm']
    syn=cell[cell.detector.isin(shared)].pivot_table(index=['family','d','pi','stress'],columns='detector',values='q')[shared]
    ren={'KNN':'knn','LOF':'lof','IForest':'iforest','PCA':'pca','OCSVM':'ocsvm','GMM':'gmm'};real=r[['Dataset']+list(ren)].rename(columns=ren).set_index('Dataset')[shared]
    tests=[]
    for metric in ['raw_mad','centered_mad','z_rmse','rank_divergence']:
        obs,p1,p2=mantel_exact(pair_matrix(syn,metric),pair_matrix(real,metric));tests.append([metric,obs,p1,p2,720])
    pd.DataFrame(tests,columns=['distance','spearman_r','exact_p_one_sided_positive','exact_p_two_sided','n_permutations']).to_csv(out/'cross_domain_exact_mantel.csv',index=False)
    print('profiles',len(bb),'defined',bb.boundary50_point.notna().sum(),'median_ci',bb.loc[bb.boundary50_point.notna(),'ci_width'].median())
    print('near_equal',len(pd.read_csv(out/'real25_near_equal_eps015.csv')))
if __name__=='__main__':main()
