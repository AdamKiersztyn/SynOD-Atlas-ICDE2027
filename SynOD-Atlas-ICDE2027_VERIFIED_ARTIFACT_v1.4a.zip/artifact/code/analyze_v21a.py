"""Recompute the central SynOD-Atlas v2.1a claims from frozen execution tables.

Outputs: factorial effect sizes, metric-weight robustness, detector geometry,
competence morphology counts, real-panel near-equal pairs, and exact six-detector
synthetic-to-real Mantel-style tests.
"""
from __future__ import annotations
import argparse,itertools
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import spearmanr
import patsy
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

FORMULA="{y} ~ C(detector)+C(family)+C(d)+C(pi)+C(stress)+C(detector):C(family)+C(detector):C(stress)+C(detector):C(d)+C(detector):C(pi)+C(family):C(stress)"

def eta_table(cell,y):
    mod=smf.ols(FORMULA.format(y=y),data=cell).fit(); a=anova_lm(mod,typ=2); resid=float(a.loc['Residual','sum_sq']); a=a.drop(index='Residual').copy(); a['partial_eta2']=a.sum_sq/(a.sum_sq+resid); return mod,a

def geometry(cell,metric='q'):
    keys=['family','d','pi','stress']; dets=sorted(cell.detector.unique()); rows=[]
    for i,a in enumerate(dets):
      A=cell[cell.detector.eq(a)].sort_values(keys)[metric].to_numpy()
      for b in dets[i+1:]:
       B=cell[cell.detector.eq(b)].sort_values(keys)[metric].to_numpy(); za=(A-A.mean())/A.std(ddof=1); zb=(B-B.mean())/B.std(ddof=1)
       rows.append([a,b,A.mean(),B.mean(),abs(A.mean()-B.mean()),np.sqrt(np.mean((za-zb)**2)),spearmanr(A,B).statistic])
    return pd.DataFrame(rows,columns=['detector_a','detector_b','mean_a','mean_b','abs_mean_gap','morphology_rmse','surface_spearman'])

def morphology(metrics,tau=.30):
    cp=(metrics.assign(comp=metrics.q.ge(tau)).groupby(['family','d','pi','detector','stress'],as_index=False).comp.mean())
    rows=[]
    for key,g in cp.groupby(['family','d','pi','detector']):
      g=g.sort_values('stress'); curve=g.comp.to_numpy(); b=curve.ge(.5).astype(int) if isinstance(curve,pd.Series) else (curve>=.5).astype(int)
      comps=int(np.sum((b==1)&(np.r_[0,b[:-1]]==0)))
      if b.sum()==0: typ='never_competent'
      elif b.sum()==len(b): typ='always_competent'
      elif b[0]==1 and comps==1: typ='collapse'
      elif b[-1]==1 and comps==1: typ='emergence'
      elif comps>=2: typ='competence_island'
      else: typ='partial'
      rows.append([*key,tau,curve.mean(),b.mean(),typ,comps,';'.join(f'{v:.3f}' for v in curve)])
    prof=pd.DataFrame(rows,columns=['family','d','pi','detector','tau','mean_competence_probability','competence_volume','morphology','n_components','curve'])
    cnt=prof.morphology.value_counts().rename_axis('morphology').reset_index(name='n_profiles'); cnt['fraction']=cnt.n_profiles/len(prof)
    return prof,cnt

def threshold_sensitivity(metrics, taus=(.25,.30,.35,.40), gamma=.5):
    rows=[]
    for tau in taus:
        cp=(metrics.assign(comp=metrics.q.ge(tau).astype(float))
            .groupby(['family','d','pi','stress','detector'],as_index=False).comp.mean())
        vol=(cp.assign(ok=cp.comp.ge(gamma).astype(float)).groupby('detector',as_index=False).ok.mean())
        vol['tau']=tau; rows.append(vol.rename(columns={'ok':'competence_volume'}))
    out=pd.concat(rows,ignore_index=True)
    piv=out.pivot(index='detector',columns='tau',values='competence_volume')
    corr=piv.corr(method='spearman')
    cr=[]
    for i,a in enumerate(corr.columns):
        for b in corr.columns[i+1:]: cr.append([a,b,corr.loc[a,b]])
    return out,pd.DataFrame(cr,columns=['tau_a','tau_b','spearman_detector_order'])

def _first_loss(stress, c, gamma=.5):
    stress=np.asarray(stress,float); c=np.asarray(c,float)
    for i in range(len(stress)-1):
        if c[i]>=gamma and c[i+1]<gamma:
            if c[i]==c[i+1]: return float((stress[i]+stress[i+1])/2)
            return float(stress[i]+(gamma-c[i])*(stress[i+1]-stress[i])/(c[i+1]-c[i]))
    return np.nan

def boundary_bootstrap(metrics,tau=.30,gamma=.5,B=1000,seed=20260919):
    rng=np.random.default_rng(seed); rows=[]
    keys=['family','d','pi','detector']
    for key,g in metrics.groupby(keys,sort=True):
        piv=g.pivot_table(index='stress',columns='seed',values='q').sort_index()
        stress=piv.index.to_numpy(float); Q=piv.to_numpy(float); comp=(Q>=tau).mean(axis=1)
        point=_first_loss(stress,comp,gamma)
        vals=[]
        for _ in range(B):
            idx=rng.integers(0,Q.shape[1],size=Q.shape[1]); cb=(Q[:,idx]>=tau).mean(axis=1); v=_first_loss(stress,cb,gamma)
            if np.isfinite(v): vals.append(v)
        vals=np.asarray(vals,float)
        if len(vals): med=float(np.median(vals));lo=float(np.quantile(vals,.025));hi=float(np.quantile(vals,.975));sd=float(vals.std(ddof=1)) if len(vals)>1 else 0.
        else: med=lo=hi=sd=np.nan
        rows.append([*key,tau,point,med,lo,hi,len(vals)/B,sd,hi-lo if np.isfinite(hi) else np.nan])
    return pd.DataFrame(rows,columns=keys+['tau','boundary50_point','bootstrap_median','ci025','ci975','defined_fraction','bootstrap_sd','ci_width'])

def pair_matrix(df,metric):
    dets=list(df.columns); M=np.zeros((len(dets),len(dets)))
    for i,a in enumerate(dets):
      for j,b in enumerate(dets):
       A=df[a].to_numpy(float);B=df[b].to_numpy(float);mask=np.isfinite(A)&np.isfinite(B);A=A[mask];B=B[mask]
       if metric=='raw_mad': v=np.mean(np.abs(A-B))
       elif metric=='centered_mad': v=np.mean(np.abs((A-A.mean())-(B-B.mean())))
       elif metric=='z_rmse':
        za=(A-A.mean())/A.std(ddof=1);zb=(B-B.mean())/B.std(ddof=1);v=np.sqrt(np.mean((za-zb)**2))
       elif metric=='rank_divergence': v=1-spearmanr(A,B).statistic
       M[i,j]=v
    return M

def mantel_exact(A,B):
    iu=np.triu_indices_from(A,k=1); av=A[iu]; obs=spearmanr(av,B[iu]).statistic; vals=[]
    for perm in itertools.permutations(range(A.shape[0])):
      vals.append(spearmanr(av,B[np.ix_(perm,perm)][iu]).statistic)
    vals=np.asarray(vals); return obs,float(np.mean(vals>=obs-1e-15)),float(np.mean(np.abs(vals)>=abs(obs)-1e-15))


def inferential_robustness(metrics, cell, out, B=10000, perm_seed=20260919):
    """Recompute model build-up, seed robustness, and Freedman--Lane A:M test."""
    # Model build-up used in the manuscript.
    f_main = "q ~ C(detector)+C(family)+C(d)+C(pi)+C(stress)"
    f_am = f_main + "+C(detector):C(family)"
    f_stress = f_am + "+C(detector):C(stress)+C(family):C(stress)"
    models = [
        ("main_effects", f_main),
        ("plus_detector_x_mechanism", f_am),
        ("plus_stress_interactions", f_stress),
        ("selected_full", FORMULA.format(y="q")),
    ]
    mb=[]
    for name,form in models:
        mod=smf.ols(form,data=cell).fit()
        mb.append([name,mod.rsquared,mod.rsquared_adj,len(mod.params)])
    pd.DataFrame(mb,columns=['model','r2','adjusted_r2','n_parameters']).to_csv(out/'model_build_up_q.csv',index=False)

    # Five individual seeds and five leave-one-seed-out averages.
    sr=[]
    seeds=sorted(metrics.seed.unique())
    for seed in seeds:
        c=metrics[metrics.seed.eq(seed)].copy()
        mod,a=eta_table(c,'q'); ea=float(a.loc['C(detector)','partial_eta2']); eam=float(a.loc['C(detector):C(family)','partial_eta2'])
        sr.append(['individual_seed',int(seed),mod.rsquared,mod.rsquared_adj,ea,eam,eam/ea])
    for omitted in seeds:
        c=(metrics[~metrics.seed.eq(omitted)]
           .groupby(['family','d','pi','stress','detector'],as_index=False)['q'].mean())
        mod,a=eta_table(c,'q'); ea=float(a.loc['C(detector)','partial_eta2']); eam=float(a.loc['C(detector):C(family)','partial_eta2'])
        sr.append(['leave_one_seed_out',int(omitted),mod.rsquared,mod.rsquared_adj,ea,eam,eam/ea])
    pd.DataFrame(sr,columns=['fit_type','seed_or_omitted_seed','r2','adjusted_r2','eta_detector','eta_detector_x_mechanism','interaction_to_detector_ratio']).to_csv(out/'seed_stability_q.csv',index=False)

    # Freedman--Lane residual permutation test for A:M in the otherwise identical hierarchical model.
    full = FORMULA.format(y='q')
    reduced = "q ~ C(detector)+C(family)+C(d)+C(pi)+C(stress)+C(detector):C(stress)+C(detector):C(d)+C(detector):C(pi)+C(family):C(stress)"
    yf,Xf=patsy.dmatrices(full,cell,return_type='matrix'); yr,Xr=patsy.dmatrices(reduced,cell,return_type='matrix')
    y=np.asarray(yf).ravel(); Xf=np.asarray(Xf); Xr=np.asarray(Xr)
    Qf,_=np.linalg.qr(Xf,mode='reduced'); Qr,_=np.linalg.qr(Xr,mode='reduced')
    beta_r=np.linalg.lstsq(Xr,y,rcond=None)[0]; yhat=Xr@beta_r; resid=y-yhat
    def _sse(Q,yy): return float(yy@yy-np.sum((Q.T@yy)**2))
    observed=_sse(Qr,y)-_sse(Qf,y)
    rng=np.random.default_rng(perm_seed); gains=np.empty(B,float)
    for b in range(B):
        yp=yhat+resid[rng.permutation(len(resid))]
        gains[b]=_sse(Qr,yp)-_sse(Qf,yp)
    pval=(np.sum(gains>=observed)+1)/(B+1)
    q95,q99,q999=np.quantile(gains,[.95,.99,.999])
    pd.DataFrame({'permutation_sse_gain':gains}).to_csv(out/'freedman_lane_null_q.csv',index=False)
    pd.DataFrame([[B,perm_seed,observed,observed/np.sum((y-y.mean())**2),pval,q95,q99,q999]],
      columns=['n_permutations','rng_seed','observed_sse_gain','delta_r2','p_value','null_q95','null_q99','null_q999']).to_csv(out/'freedman_lane_q.csv',index=False)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--metrics',required=True); ap.add_argument('--real',required=True); ap.add_argument('--output',default='analysis_reproduced'); ap.add_argument('--skip-remainder',action='store_true'); args=ap.parse_args(); out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    m=pd.read_csv(args.metrics); m['s_auc']=np.clip(2*(m.roc_auc-.5),0,1);m['s_ap']=np.clip((m.average_precision-m.pi)/(1-m.pi),0,1)
    cell=m.groupby(['family','d','pi','stress','detector'],as_index=False)[['q','s_auc','s_ap']].mean()
    effects=[]
    for y in ['q','s_auc','s_ap']:
      mod,a=eta_table(cell,y); a.reset_index(names='effect').assign(response=y,model_r2=mod.rsquared,model_adj_r2=mod.rsquared_adj).to_csv(out/f'factorial_effects_{y}.csv',index=False)
      for eff in ['C(family)','C(detector)','C(detector):C(family)']:
       effects.append([y,eff,a.loc[eff,'partial_eta2'],mod.rsquared_adj])
    pd.DataFrame(effects,columns=['response','effect','partial_eta2','adjusted_r2']).to_csv(out/'metric_robustness_core.csv',index=False)
    inferential_robustness(m,cell,out)
    wr=[]
    for i,w in enumerate(np.linspace(0,1,11)):
      y=f'qw{i}';cell[y]=w*cell.s_auc+(1-w)*cell.s_ap;mod,a=eta_table(cell,y);ea=a.loc['C(detector)','partial_eta2'];eam=a.loc['C(detector):C(family)','partial_eta2'];wr.append([w,mod.rsquared_adj,a.loc['C(family)','partial_eta2'],ea,eam,eam/ea])
    pd.DataFrame(wr,columns=['auc_weight','adjusted_r2','eta_mechanism','eta_detector','eta_detector_x_mechanism','interaction_to_detector_ratio']).to_csv(out/'metric_weight_sweep.csv',index=False)
    geometry(cell,'q').to_csv(out/'detector_pair_geometry_q.csv',index=False)
    geometry(cell,'s_auc').to_csv(out/'detector_pair_geometry_auc.csv',index=False)
    geometry(cell,'s_ap').to_csv(out/'detector_pair_geometry_ap.csv',index=False)
    prof,cnt=morphology(m,.30);prof.to_csv(out/'profile_morphology_tau030.csv',index=False);cnt.to_csv(out/'morphology_counts_tau030.csv',index=False)
    ts,tc=threshold_sensitivity(m);ts.to_csv(out/'threshold_sensitivity_detectors.csv',index=False);tc.to_csv(out/'threshold_order_stability.csv',index=False)
    if args.skip_remainder:
      print('wrote core',out); return
    bb=boundary_bootstrap(m,.30);bb.to_csv(out/'boundary_bootstrap_tau030.csv',index=False)

    r=pd.read_csv(args.real); dets=[c for c in r.columns if c!='Dataset']; pairs=[]
    for i,a in enumerate(dets):
      for b in dets[i+1:]:
       x=r[a].to_numpy(float);y=r[b].to_numpy(float);mask=np.isfinite(x)&np.isfinite(y);x=x[mask];y=y[mask]
       if len(x)<10: continue
       pairs.append([a,b,len(x),x.mean(),y.mean(),abs(x.mean()-y.mean()),spearmanr(x,y).statistic,np.mean(np.abs((x-x.mean())-(y-y.mean())))])
    rp=pd.DataFrame(pairs,columns=['detector_a','detector_b','n_real_datasets','mean_a','mean_b','abs_mean_gap','profile_spearman','centered_mad']);rp.to_csv(out/'real25_pairwise_profile_geometry.csv',index=False)
    rp[(rp.abs_mean_gap<=.015)&(rp.n_real_datasets>=25)].sort_values('profile_spearman').to_csv(out/'real25_near_equal_eps015.csv',index=False)

    shared=['knn','lof','iforest','pca','ocsvm','gmm']; syn=cell[cell.detector.isin(shared)].pivot_table(index=['family','d','pi','stress'],columns='detector',values='q')[shared]
    ren={'KNN':'knn','LOF':'lof','IForest':'iforest','PCA':'pca','OCSVM':'ocsvm','GMM':'gmm'}; real=r[['Dataset']+list(ren)].rename(columns=ren).set_index('Dataset')[shared]
    tests=[]
    for metric in ['raw_mad','centered_mad','z_rmse','rank_divergence']:
      obs,p1,p2=mantel_exact(pair_matrix(syn,metric),pair_matrix(real,metric));tests.append([metric,obs,p1,p2,720])
    pd.DataFrame(tests,columns=['distance','spearman_r','exact_p_one_sided_positive','exact_p_two_sided','n_permutations']).to_csv(out/'cross_domain_exact_mantel.csv',index=False)
    print('wrote',out)
if __name__=='__main__': main()
