"""Recompute claim tables and principal figures from the released frozen tables."""
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--artifact-root',default=str(Path(__file__).resolve().parents[1]));ap.add_argument('--output',default='reproduced_release');a=ap.parse_args()
    root=Path(a.artifact_root).resolve();out=Path(a.output).resolve();analysis=out/'analysis';figs=out/'figures';analysis.mkdir(parents=True,exist_ok=True);figs.mkdir(parents=True,exist_ok=True)
    code=Path(__file__).resolve().parent
    subprocess.check_call([sys.executable,str(code/'analyze_v21a.py'),'--metrics',str(root/'core_metrics.csv'),'--real',str(root/'real31_detector_profiles.csv'),'--output',str(analysis),'--skip-remainder']); subprocess.check_call([sys.executable,str(code/'analyze_v10_remainder.py'),'--metrics',str(root/'core_metrics.csv'),'--real',str(root/'real31_detector_profiles.csv'),'--output',str(analysis)])
    subprocess.check_call([sys.executable,str(code/'build_paper_figures_v21a.py'),'--metrics',str(root/'core_metrics.csv'),'--real',str(root/'real31_detector_profiles.csv'),'--analysis',str(analysis),'--output',str(figs)])
    sample_analysis=out/'sample_size_analysis';sample_analysis.mkdir(parents=True,exist_ok=True)
    subprocess.check_call([sys.executable,str(code/'analyze_sample_size_extension_v11.py'),'--metrics',str(root/'sample_size_extension_v11'/'sample_size_n250_to_10000_all_metrics.csv'),'--output',str(sample_analysis)])
    subprocess.check_call([sys.executable,str(code/'build_sample_size_figure_v11.py'),'--analysis',str(sample_analysis),'--output',str(figs)])
    subprocess.check_call([sys.executable,str(code/'reproduce_hyperparameters.py'),'--artifact-root',str(root),'--output',str(out/'hyperparameters')])
    print('reproduced',out)
if __name__=='__main__': main()
