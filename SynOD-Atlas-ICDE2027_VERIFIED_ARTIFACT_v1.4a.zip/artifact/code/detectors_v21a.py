"""Audited detector wrappers used by SynOD-Atlas v2.1a.

Identical to the v1.4 scikit-learn panel except PCA retains at least one
residual direction: n_components=min(20,d-1,n-1).
"""
from __future__ import annotations
import numpy as np
from sklearn.decomposition import PCA
from synod_atlas.detectors import *  # noqa: F401,F403
from synod_atlas import detectors as _base

class PCADetectorV21A:
    def __init__(self,n_components:int=20): self.n_components=n_components
    def fit_score(self,X,random_state:int):
        max_comp=min(X.shape[0]-1,X.shape[1]-1,self.n_components)
        if max_comp<1: return np.zeros(X.shape[0])
        solver='randomized' if min(X.shape)>50 and max_comp<min(X.shape) else 'full'
        pca=PCA(n_components=max_comp,svd_solver=solver,random_state=random_state)
        Z=pca.fit_transform(X); Xh=pca.inverse_transform(Z)
        return np.mean((X-Xh)**2,axis=1)

_FACT=dict(_base._FACTORIES); _FACT['pca']=PCADetectorV21A
DEFAULT_DETECTORS=list(_base.DEFAULT_DETECTORS)

def make_detector_v21a(name:str):
    key=name.lower()
    if key in _base.EXCLUDED_METHODS: raise ValueError(f'{key} excluded by policy')
    if key not in _FACT: raise ValueError(key)
    return _FACT[key]()

def run_detector_v21a(name,X,*,random_state=1):
    from time import perf_counter
    start=perf_counter()
    try:
        scores=np.asarray(make_detector_v21a(name).fit_score(X,random_state=random_state),float).ravel()
        if len(scores)!=len(X) or not np.all(np.isfinite(scores)): raise RuntimeError('invalid scores')
        return _base.DetectorRun(name,'ok',scores,perf_counter()-start)
    except Exception as exc:
        return _base.DetectorRun(name,'error',None,perf_counter()-start,repr(exc))
