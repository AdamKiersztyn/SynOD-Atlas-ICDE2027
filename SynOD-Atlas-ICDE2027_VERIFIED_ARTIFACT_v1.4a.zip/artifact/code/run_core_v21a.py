"""Regenerate the complete 2,100-dataset / 16,800-run SynOD-Atlas v2.1a core."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from generators_v21 import generate_v21,STRESSES
from detectors_v21a import DEFAULT_DETECTORS,run_detector_v21a
from synod_atlas.evaluation import compute_metrics

FAMILIES=[f'F{i:02d}' for i in range(1,11)]
DS=[10,50,100]; PIS=[.05,.10]; SEEDS=[1,2,3,4,5]

def dsid(f,d,n,pi,h,s):
    return f'{f}_d{d}_n{n}_pi{int(round(pi*100)):02d}_stress{int(round(h*600)):03d}_seed{s:02d}'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default='v21a_core'); ap.add_argument('--n',type=int,default=500); args=ap.parse_args()
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    mrows=[]; rrows=[]
    for fam in FAMILIES:
      for d in DS:
       for pi in PIS:
        for h in STRESSES:
         for seed in SEEDS:
          X,y,m=generate_v21(fam,args.n,d,pi,h,seed)
          did=dsid(fam,d,args.n,pi,h,seed); m=dict(m); m['dataset_id']=did; mrows.append(m)
          for det in DEFAULT_DETECTORS:
           r=run_detector_v21a(det,X,random_state=seed)
           row={'dataset_id':did,'family':fam,'d':d,'n':args.n,'pi':pi,'stress':h,'seed':seed,'detector':det,'status':r.status,'runtime_sec':r.runtime_sec,'error':r.error}
           if r.status=='ok':
            z=compute_metrics(y,r.scores); row.update(roc_auc=z['roc_auc'],average_precision=z['average_precision'],q=z['rank_quality'])
           rrows.append(row)
    pd.DataFrame(mrows).to_csv(out/'datasets_metadata.csv',index=False)
    pd.DataFrame(rrows).to_csv(out/'metrics.csv',index=False)
    print(f'datasets={len(mrows)} runs={len(rrows)} errors={sum(r["status"]!="ok" for r in rrows)}')
if __name__=='__main__': main()
