"""SynOD-Atlas v1.4-DMKD."""
from .generators import generate_dataset, GENERATORS, FAMILY_NAMES
from .detectors import DEFAULT_DETECTORS, DETECTOR_SPECS, run_detector
from .evaluation import compute_metrics, dataset_difficulty_index, difficulty_variants
__all__=['generate_dataset','GENERATORS','FAMILY_NAMES','DEFAULT_DETECTORS','DETECTOR_SPECS','run_detector','compute_metrics','dataset_difficulty_index','difficulty_variants']
__version__='1.4.0'
