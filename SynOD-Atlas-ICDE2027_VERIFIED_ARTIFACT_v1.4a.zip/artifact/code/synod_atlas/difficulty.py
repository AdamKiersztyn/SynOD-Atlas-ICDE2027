"""Difficulty descriptors for SynOD-Atlas v1.4-DMKD."""
from __future__ import annotations
from typing import Dict
import numpy as np
from scipy.stats import kurtosis, skew
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import pairwise_distances
from sklearn.neighbors import NearestNeighbors


def oracle_difficulty_descriptors(X: np.ndarray, y: np.ndarray) -> Dict[str,float]:
    X=np.asarray(X,float); y=np.asarray(y,int)
    Xn=X[y==0]; Xa=X[y==1]
    mu_n=Xn.mean(0); mu_a=Xa.mean(0)
    spread=np.mean(Xn.std(0))+np.mean(Xa.std(0))+1e-12
    sep=np.linalg.norm(mu_n-mu_a)/spread
    k_n=min(5,max(1,len(Xn)-1)); k_a=min(5,max(1,len(Xa)-1))
    nn_n=NearestNeighbors(n_neighbors=k_n+1).fit(Xn).kneighbors(Xn)[0][:,1:].mean()
    if len(Xa)>1:
        nn_a=NearestNeighbors(n_neighbors=k_a+1).fit(Xa).kneighbors(Xa)[0][:,1:].mean()
    else: nn_a=np.nan
    return {
        'oracle_separability':float(sep),
        'oracle_normal_knn':float(nn_n),
        'oracle_anomaly_knn':float(nn_a),
        'oracle_density_ratio':float(nn_n/(nn_a+1e-12)) if np.isfinite(nn_a) else np.nan,
        'oracle_contamination':float(y.mean()),
    }


def observable_difficulty_descriptors(X: np.ndarray) -> Dict[str,float]:
    """Label-free meta-features intended for deployment-time difficulty modelling."""
    X=np.asarray(X,float); n,d=X.shape
    # Standardized generators make scale moments interpretable and stable.
    s=np.std(X,axis=0); s[s==0]=1
    z=(X-np.mean(X,axis=0))/s
    sk=np.nan_to_num(skew(z,axis=0,bias=False),nan=0,posinf=0,neginf=0)
    ku=np.nan_to_num(kurtosis(z,axis=0,fisher=True,bias=False),nan=0,posinf=0,neginf=0)
    # Correlation structure; subsample dimensions for very wide matrices.
    if d>120:
        idx=np.linspace(0,d-1,120,dtype=int); Zc=z[:,idx]
    else: Zc=z
    C=np.corrcoef(Zc,rowvar=False)
    if np.ndim(C)==0:
        mean_abs_corr=0.; max_abs_corr=0.
    else:
        upper=np.abs(C[np.triu_indices_from(C,k=1)])
        mean_abs_corr=float(np.nanmean(upper)) if len(upper) else 0.
        max_abs_corr=float(np.nanmax(upper)) if len(upper) else 0.
    # Local distance heterogeneity.
    k=min(10,n-1)
    dist=NearestNeighbors(n_neighbors=k+1,n_jobs=1).fit(z).kneighbors(z)[0][:,1:].mean(axis=1)
    q10,q50,q90=np.quantile(dist,[.1,.5,.9])
    # Compact PCA spectrum proxy.
    nc=min(20,n-1,d)
    pca=PCA(n_components=nc,svd_solver='randomized' if min(n,d)>50 and nc<min(n,d) else 'full',random_state=123)
    pca.fit(z)
    ev=np.maximum(pca.explained_variance_,1e-12)
    pr=float(ev.sum()**2/np.sum(ev**2))
    # Clusterability: relative inertia improvement from 1 to 3 clusters on a fixed sample.
    rng=np.random.default_rng(123)
    sub=z[rng.choice(n,size=min(n,300),replace=False)]
    mu=sub.mean(axis=0)
    inertia1=float(np.sum((sub-mu)**2))
    km=KMeans(n_clusters=3,n_init=3,max_iter=100,random_state=123).fit(sub)
    clusterability=float(max(0.,min(1.,1.-km.inertia_/(inertia1+1e-12))))
    return {
        'obs_n_samples':float(n), 'obs_n_features':float(d), 'obs_d_over_n':float(d/n),
        'obs_mean_abs_skew':float(np.mean(np.abs(sk))), 'obs_mean_abs_kurtosis':float(np.mean(np.abs(ku))),
        'obs_mean_abs_corr':mean_abs_corr, 'obs_max_abs_corr':max_abs_corr,
        'obs_knn_mean':float(dist.mean()), 'obs_knn_cv':float(dist.std()/(dist.mean()+1e-12)),
        'obs_knn_q90_q10':float(q90/(q10+1e-12)), 'obs_knn_q90_q50':float(q90/(q50+1e-12)),
        'obs_pca_first_ratio':float(pca.explained_variance_ratio_[0]),
        'obs_pca_top5_ratio':float(pca.explained_variance_ratio_[:min(5,nc)].sum()),
        'obs_effective_rank20':pr, 'obs_clusterability3':clusterability,
    }

# Backward compatibility alias.
def basic_difficulty_descriptors(X,y,**kwargs):
    out=oracle_difficulty_descriptors(X,y); out.update(observable_difficulty_descriptors(X)); return out
