"""Benchmark pipeline helpers for SynOD-Atlas v1.4-DMKD."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Tuple

import numpy as np
import pandas as pd

from .detectors import DEFAULT_DETECTORS, run_detector
from .difficulty import basic_difficulty_descriptors
from .evaluation import compute_metrics, dataset_difficulty_index, method_summary
from .generators import generate_dataset
from .metadata import flatten_metadata, metadata_frame
from .utils import save_dataset_bundle
from .validation import assert_valid_dataset


def iter_dataset_grid(
    *,
    families: Iterable[str],
    dimensions: Iterable[int],
    contaminations: Iterable[float],
    difficulties: Iterable[str],
    seeds: Iterable[int],
):
    """Yield parameter dictionaries for a Cartesian dataset grid."""
    for family_id in families:
        for n_features in dimensions:
            for contamination in contaminations:
                for difficulty in difficulties:
                    for seed in seeds:
                        yield {
                            "family_id": family_id,
                            "n_features": int(n_features),
                            "contamination": float(contamination),
                            "difficulty": str(difficulty),
                            "seed": int(seed),
                        }


def run_generated_benchmark(
    *,
    n_samples: int,
    families: Iterable[str],
    dimensions: Iterable[int],
    contaminations: Iterable[float],
    difficulties: Iterable[str],
    seeds: Iterable[int],
    detectors: Iterable[str] | None = None,
    output_dir: str | Path | None = None,
    save_data: bool = False,
    save_scores: bool = False,
    compute_descriptors: bool = True,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Generate datasets, run detectors and return metadata/metrics/DI/summary.

    Returns
    -------
    metadata_df, metrics_df, difficulty_df, method_summary_df
    """
    detector_list = list(detectors) if detectors is not None else list(DEFAULT_DETECTORS)
    output_path = Path(output_dir) if output_dir is not None else None
    if output_path is not None:
        output_path.mkdir(parents=True, exist_ok=True)
        if save_scores:
            (output_path / "scores").mkdir(parents=True, exist_ok=True)

    metadata_records: List[dict] = []
    metrics_records: List[dict] = []

    for params in iter_dataset_grid(
        families=families,
        dimensions=dimensions,
        contaminations=contaminations,
        difficulties=difficulties,
        seeds=seeds,
    ):
        X, y, meta = generate_dataset(n_samples=n_samples, **params)
        assert_valid_dataset(X, y, meta)
        if compute_descriptors:
            meta.update(basic_difficulty_descriptors(X, y))
        metadata_records.append(meta)

        if output_path is not None and save_data:
            save_dataset_bundle(output_path / "data", X, y, meta, fmt="csv")

        for detector in detector_list:
            run = run_detector(detector, X, contamination=float(meta["contamination"]), random_state=int(meta["seed"]))
            base = {
                "dataset_id": meta["dataset_id"],
                "family_id": meta["family_id"],
                "family_name": meta["family_name"],
                "n_features": meta["n_features"],
                "n_samples": meta["n_samples"],
                "contamination": meta["contamination"],
                "difficulty": meta["difficulty"],
                "seed": meta["seed"],
                "detector": detector,
                "status": run.status,
                "runtime_sec": run.runtime_sec,
                "error": run.error,
            }
            if run.status == "ok" and run.scores is not None:
                metrics = compute_metrics(y, run.scores)
                base.update(metrics)
                if output_path is not None and save_scores:
                    score_file = output_path / "scores" / f"{meta['dataset_id']}__{detector}.csv"
                    np.savetxt(score_file, run.scores, delimiter=",", fmt="%.8g")
                    base["score_file"] = str(score_file.relative_to(output_path))
            else:
                base.update({
                    "n_anomaly": np.nan,
                    "balanced_accuracy": np.nan,
                    "precision": np.nan,
                    "recall": np.nan,
                    "f1": np.nan,
                    "mcc": np.nan,
                    "roc_auc": np.nan,
                    "average_precision": np.nan,
                    "precision_at_k": np.nan,
                    "recall_at_k": np.nan,
                    "rank_quality": np.nan,
                    "composite_quality": np.nan,
                    "auc_norm": np.nan,
                    "ap_norm": np.nan,
                })
            metrics_records.append(base)

    metadata_df = metadata_frame(metadata_records)
    metrics_df = pd.DataFrame(metrics_records)
    difficulty_df = dataset_difficulty_index(metrics_df)
    summary_df = method_summary(metrics_df)

    if output_path is not None:
        metadata_df.to_csv(output_path / "datasets_metadata.csv", index=False)
        metrics_df.to_csv(output_path / "metrics.csv", index=False)
        difficulty_df.to_csv(output_path / "dataset_difficulty.csv", index=False)
        summary_df.to_csv(output_path / "method_summary.csv", index=False)

    return metadata_df, metrics_df, difficulty_df, summary_df
