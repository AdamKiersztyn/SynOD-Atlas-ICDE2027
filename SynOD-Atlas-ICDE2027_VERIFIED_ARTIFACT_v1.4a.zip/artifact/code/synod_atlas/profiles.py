"""Detector-principle profile analysis for SynOD-Atlas v1.4-DMKD."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from .detectors import DETECTOR_SPECS
from .evaluation import family_method_matrix


def detector_family_profile(metrics_df: pd.DataFrame, value: str = "rank_quality") -> pd.DataFrame:
    """Return detector rows and family columns with mean benchmark performance."""
    matrix = family_method_matrix(metrics_df, value=value)
    profile = matrix.T.reset_index()
    if profile.columns[0] != "detector":
        profile = profile.rename(columns={profile.columns[0]: "detector"})
    return profile


def detector_principle_summary(metrics_df: pd.DataFrame, value: str = "rank_quality") -> pd.DataFrame:
    """Aggregate performance by detector principle rather than implementation count."""
    specs = pd.DataFrame([
        {"detector": name, "principle": spec.principle, "implementation": spec.implementation}
        for name, spec in DETECTOR_SPECS.items()
    ])
    ok = metrics_df[metrics_df["status"].eq("ok")].copy() if "status" in metrics_df.columns else metrics_df.copy()
    merged = ok.merge(specs, on="detector", how="left")
    return merged.groupby(["principle", "family_id"], dropna=False).agg(
        mean_value=(value, "mean"),
        mean_roc_auc=("roc_auc", "mean"),
        mean_average_precision=("average_precision", "mean"),
        mean_f1=("f1", "mean"),
        mean_runtime_sec=("runtime_sec", "mean"),
        n_runs=("dataset_id", "count"),
    ).reset_index().sort_values(["principle", "family_id"])

# Backward-compatible function name used by earlier scripts.
def detector_group_summary(metrics_df: pd.DataFrame, value: str = "rank_quality") -> pd.DataFrame:
    out = detector_principle_summary(metrics_df, value=value).copy()
    return out.rename(columns={"principle": "detector_group"})


def cluster_detectors_by_profile(metrics_df: pd.DataFrame, *, value: str = "rank_quality", n_clusters: int = 5) -> pd.DataFrame:
    """Cluster detectors according to family-level performance signatures."""
    profile = detector_family_profile(metrics_df, value=value)
    detectors = profile["detector"].tolist()
    X = profile.drop(columns=["detector"]).fillna(profile.drop(columns=["detector"]).mean()).fillna(0.0).values
    if len(detectors) == 0:
        return pd.DataFrame(columns=["detector", "profile_cluster"])
    if len(detectors) == 1:
        return pd.DataFrame({"detector": detectors, "profile_cluster": [1]})
    k = max(1, min(int(n_clusters), len(detectors)))
    if k == 1:
        labels = np.zeros(len(detectors), dtype=int)
    else:
        Xs = X - X.mean(axis=1, keepdims=True)
        denom = Xs.std(axis=1, keepdims=True)
        denom[denom == 0] = 1.0
        Xs = Xs / denom
        labels = AgglomerativeClustering(n_clusters=k, linkage="ward").fit_predict(Xs)
    return pd.DataFrame({"detector": detectors, "profile_cluster": labels + 1}).sort_values("profile_cluster")


def family_hardness_profile(metrics_df: pd.DataFrame, value: str = "rank_quality") -> pd.DataFrame:
    """Summarize which detector principles are strong/weak for each family."""
    group_df = detector_principle_summary(metrics_df, value=value)
    out_rows = []
    for family, part in group_df.groupby("family_id"):
        part = part.sort_values("mean_value", ascending=False)
        best, worst = part.iloc[0], part.iloc[-1]
        out_rows.append({
            "family_id": family,
            "best_detector_principle": best["principle"],
            "best_principle_mean_value": best["mean_value"],
            "weakest_detector_principle": worst["principle"],
            "weakest_principle_mean_value": worst["mean_value"],
            "principle_spread": best["mean_value"] - worst["mean_value"],
        })
    return pd.DataFrame(out_rows).sort_values("principle_spread", ascending=False)
