"""Validation helpers for SynOD-Atlas datasets."""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np


def validate_dataset(X: np.ndarray, y: np.ndarray, metadata: Dict[str, Any]) -> List[str]:
    """Return a list of validation problems. Empty list means OK."""
    problems: List[str] = []

    n_samples = int(metadata.get("n_samples", -1))
    n_features = int(metadata.get("n_features", -1))
    n_anomaly = int(metadata.get("n_anomaly", -1))

    if X.ndim != 2:
        problems.append("X must be 2-dimensional")
    else:
        if X.shape[0] != n_samples:
            problems.append(f"X has {X.shape[0]} rows, expected {n_samples}")
        if X.shape[1] != n_features:
            problems.append(f"X has {X.shape[1]} columns, expected {n_features}")

    if y.ndim != 1:
        problems.append("y must be 1-dimensional")
    elif len(y) != n_samples:
        problems.append(f"y has length {len(y)}, expected {n_samples}")

    unique = set(np.unique(y).tolist())
    if unique - {0, 1}:
        problems.append(f"y contains labels outside {{0, 1}}: {sorted(unique)}")

    if int(np.sum(y == 1)) != n_anomaly:
        problems.append(f"y contains {int(np.sum(y == 1))} anomalies, expected {n_anomaly}")

    if not np.all(np.isfinite(X)):
        problems.append("X contains NaN or infinite values")

    constant_cols = np.where(X.std(axis=0) == 0)[0].tolist() if X.ndim == 2 else []
    if constant_cols:
        problems.append(f"X contains constant columns: {constant_cols[:10]}")

    return problems


def assert_valid_dataset(X: np.ndarray, y: np.ndarray, metadata: Dict[str, Any]) -> None:
    """Raise ValueError if dataset validation fails."""
    problems = validate_dataset(X, y, metadata)
    if problems:
        raise ValueError("Dataset validation failed:\n" + "\n".join(f"- {p}" for p in problems))
