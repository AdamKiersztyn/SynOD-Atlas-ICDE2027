"""Utility functions for SynOD-Atlas generators."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, Tuple

import numpy as np


def sample_unit_vector(d: int, rng: np.random.Generator) -> np.ndarray:
    """Sample one random unit vector in R^d."""
    if d <= 0:
        raise ValueError("d must be positive")
    v = rng.normal(0.0, 1.0, size=d)
    norm = np.linalg.norm(v)
    if norm == 0:
        v[0] = 1.0
        norm = 1.0
    return v / norm


def sample_unit_vectors(n: int, d: int, rng: np.random.Generator) -> np.ndarray:
    """Sample n random unit vectors in R^d."""
    if n <= 0:
        return np.empty((0, d))
    V = rng.normal(0.0, 1.0, size=(n, d))
    norms = np.linalg.norm(V, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return V / norms


def standardize(X: np.ndarray) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Z-score standardization with safe handling of constant columns."""
    mean = X.mean(axis=0)
    std = X.std(axis=0)
    constant_columns = np.where(std == 0)[0].tolist()
    std_safe = std.copy()
    std_safe[std_safe == 0] = 1.0
    Xs = (X - mean) / std_safe
    return Xs, {
        "scaled": True,
        "scaling": "zscore_full_dataset",
        "constant_columns": constant_columns,
    }


def shuffle_dataset(
    X: np.ndarray,
    y: np.ndarray,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Shuffle X and y using the same permutation."""
    idx = rng.permutation(len(y))
    return X[idx], y[idx], idx


def split_normal_anomaly_counts(n_samples: int, contamination: float) -> Tuple[int, int]:
    """Return n_normal, n_anomaly for a requested contamination."""
    if n_samples <= 0:
        raise ValueError("n_samples must be positive")
    if not 0 < contamination < 1:
        raise ValueError("contamination must be in (0, 1)")
    n_anomaly = int(np.floor(contamination * n_samples))
    n_anomaly = max(1, min(n_samples - 1, n_anomaly))
    n_normal = n_samples - n_anomaly
    return n_normal, n_anomaly


def encode_pi(contamination: float) -> str:
    """Encode contamination as piXX or piXXX."""
    return f"pi{int(round(contamination * 100)):02d}"


def dataset_id(
    family_id: str,
    family_short: str,
    n_features: int,
    n_samples: int,
    contamination: float,
    difficulty: str,
    seed: int,
    extra: str | None = None,
) -> str:
    """Build a compact, reproducible dataset identifier."""
    parts = [
        family_id,
        family_short.upper(),
        f"d{n_features}",
        f"n{n_samples}",
        encode_pi(contamination),
        f"diff{difficulty}",
    ]
    if extra:
        parts.append(extra)
    parts.append(f"seed{seed:02d}")
    return "_".join(parts)


def make_base_metadata(
    *,
    family_id: str,
    family_name: str,
    family_short: str,
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    n_normal: int,
    n_anomaly: int,
    extra_id: str | None = None,
) -> Dict[str, Any]:
    """Construct standard metadata shared by all generators."""
    return {
        "dataset_id": dataset_id(
            family_id,
            family_short,
            n_features,
            n_samples,
            contamination,
            difficulty,
            seed,
            extra=extra_id,
        ),
        "family_id": family_id,
        "family_name": family_name,
        "family_short": family_short,
        "n_samples": int(n_samples),
        "n_features": int(n_features),
        "n_normal": int(n_normal),
        "n_anomaly": int(n_anomaly),
        "contamination": float(contamination),
        "difficulty": difficulty,
        "seed": int(seed),
        "generator_version": "1.4",
    }


def orthonormal_embedding_matrix(input_dim: int, output_dim: int, rng: np.random.Generator) -> np.ndarray:
    """Create an output_dim x input_dim semi-orthonormal embedding matrix."""
    if input_dim > output_dim:
        raise ValueError("input_dim cannot exceed output_dim")
    A = rng.normal(size=(output_dim, input_dim))
    Q, _ = np.linalg.qr(A)
    return Q[:, :input_dim]


def sample_uniform_inside_ball(
    n: int,
    d: int,
    radius: float,
    rng: np.random.Generator,
) -> np.ndarray:
    """Sample uniformly inside a d-dimensional ball."""
    directions = sample_unit_vectors(n, d, rng)
    radii = radius * rng.random(n) ** (1.0 / d)
    return directions * radii[:, None]


def save_dataset_bundle(
    output_dir: str | Path,
    X: np.ndarray,
    y: np.ndarray,
    metadata: Dict[str, Any],
    *,
    fmt: str = "csv",
) -> None:
    """Save a dataset as X, y and metadata files."""
    output = Path(output_dir) / metadata["family_id"] / metadata["dataset_id"]
    output.mkdir(parents=True, exist_ok=True)

    if fmt == "csv":
        np.savetxt(output / "X.csv", X, delimiter=",", fmt="%.8g")
        np.savetxt(output / "y.csv", y.astype(int), delimiter=",", fmt="%d")
    elif fmt == "npy":
        np.save(output / "X.npy", X)
        np.save(output / "y.npy", y.astype(int))
    else:
        raise ValueError("fmt must be 'csv' or 'npy'")

    with (output / "metadata.json").open("w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False, default=_json_default)

    with (output / "README.md").open("w", encoding="utf-8") as f:
        f.write(f"# {metadata['dataset_id']}\n\n")
        f.write(f"Family: {metadata['family_id']} — {metadata['family_name']}\n\n")
        f.write(f"Samples: {metadata['n_samples']}, features: {metadata['n_features']}, ")
        f.write(f"contamination: {metadata['contamination']}, difficulty: {metadata['difficulty']}\n")


def _json_default(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)!r} is not JSON serializable")
