"""Open-source detector panel for SynOD-Atlas v1.4-DMKD.

Only public scikit-learn implementations (or transparent score transformations
of those estimators) are used in the empirical benchmark. RCOD, FROD and EFROD
are intentionally absent. No detector receives the true anomaly prevalence as a
training hyperparameter.
"""
from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Any, Callable, Dict, Iterable, List, Optional

import numpy as np
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
from sklearn.mixture import GaussianMixture
from sklearn.neighbors import LocalOutlierFactor, NearestNeighbors
from sklearn.svm import OneClassSVM

Array = np.ndarray

@dataclass(frozen=True)
class DetectorSpec:
    name: str
    principle: str
    implementation: str
    description: str
    parameters: str

@dataclass
class DetectorRun:
    detector: str
    status: str
    scores: Optional[Array]
    runtime_sec: float
    error: str = ""

class KNNDistanceDetector:
    def __init__(self, n_neighbors: int = 20): self.n_neighbors = n_neighbors
    def fit_score(self, X: Array, random_state: int) -> Array:
        k = min(max(2, self.n_neighbors), X.shape[0]-1)
        nn = NearestNeighbors(n_neighbors=k+1, n_jobs=1).fit(X)
        dist, _ = nn.kneighbors(X)
        return dist[:, -1]

class AvgKNNDistanceDetector:
    def __init__(self, n_neighbors: int = 20): self.n_neighbors = n_neighbors
    def fit_score(self, X: Array, random_state: int) -> Array:
        k = min(max(2, self.n_neighbors), X.shape[0]-1)
        nn = NearestNeighbors(n_neighbors=k+1, n_jobs=1).fit(X)
        dist, _ = nn.kneighbors(X)
        return dist[:, 1:].mean(axis=1)

class LOFDetector:
    def __init__(self, n_neighbors: int = 20): self.n_neighbors = n_neighbors
    def fit_score(self, X: Array, random_state: int) -> Array:
        k = min(max(2, self.n_neighbors), X.shape[0]-1)
        # contamination='auto' prevents access to the true prevalence.
        model = LocalOutlierFactor(n_neighbors=k, contamination='auto', n_jobs=1)
        model.fit_predict(X)
        return -model.negative_outlier_factor_

class IsolationForestDetector:
    def __init__(self, n_estimators: int = 100): self.n_estimators = n_estimators
    def fit_score(self, X: Array, random_state: int) -> Array:
        model = IsolationForest(n_estimators=self.n_estimators, contamination='auto',
                                random_state=random_state, n_jobs=1)
        model.fit(X)
        return -model.score_samples(X)

class PCADetector:
    def __init__(self, n_components: int = 20): self.n_components = n_components
    def fit_score(self, X: Array, random_state: int) -> Array:
        max_comp = min(X.shape[0]-1, X.shape[1], self.n_components)
        if max_comp < 1: return np.zeros(X.shape[0])
        solver = 'randomized' if min(X.shape) > 50 and max_comp < min(X.shape) else 'full'
        pca = PCA(n_components=max_comp, svd_solver=solver, random_state=random_state)
        Z = pca.fit_transform(X)
        Xh = pca.inverse_transform(Z)
        return np.mean((X-Xh)**2, axis=1)

class OneClassSVMDetector:
    def __init__(self, nu: float = 0.05): self.nu = nu
    def fit_score(self, X: Array, random_state: int) -> Array:
        # Fixed nu: deliberately independent of ground-truth contamination.
        model = OneClassSVM(kernel='rbf', gamma='scale', nu=self.nu)
        model.fit(X)
        return -model.decision_function(X).ravel()

class KMeansDistanceDetector:
    def __init__(self, n_clusters: int = 8): self.n_clusters = n_clusters
    def fit_score(self, X: Array, random_state: int) -> Array:
        k = min(self.n_clusters, max(2, X.shape[0]//50))
        model = KMeans(n_clusters=k, random_state=random_state, n_init=5, max_iter=200)
        labels = model.fit_predict(X)
        return np.linalg.norm(X-model.cluster_centers_[labels], axis=1)

class GaussianMixtureDetector:
    def __init__(self, n_components: int = 3): self.n_components = n_components
    def fit_score(self, X: Array, random_state: int) -> Array:
        k = min(self.n_components, max(1, X.shape[0]//50))
        model = GaussianMixture(n_components=k, covariance_type='diag', reg_covar=1e-6,
                                max_iter=100, n_init=1, random_state=random_state)
        model.fit(X)
        return -model.score_samples(X)

DETECTOR_SPECS: Dict[str, DetectorSpec] = {
    'knn': DetectorSpec('knn','distance','scikit-learn','Distance to the 20th nearest neighbour.','n_neighbors=20'),
    'avg_knn': DetectorSpec('avg_knn','distance','scikit-learn','Mean distance to 20 nearest neighbours.','n_neighbors=20'),
    'lof': DetectorSpec('lof','local_density','scikit-learn','Local Outlier Factor score.','n_neighbors=20; contamination=auto'),
    'iforest': DetectorSpec('iforest','isolation','scikit-learn','Isolation Forest score.','n_estimators=100; contamination=auto'),
    'pca': DetectorSpec('pca','projection','scikit-learn','PCA reconstruction error.','n_components<=20'),
    'ocsvm': DetectorSpec('ocsvm','boundary','scikit-learn','RBF One-Class SVM.','gamma=scale; nu=0.05 fixed'),
    'kmeans': DetectorSpec('kmeans','clustering','scikit-learn','Distance to nearest KMeans centroid.','n_clusters=8; n_init=5'),
    'gmm': DetectorSpec('gmm','probabilistic_density','scikit-learn','Negative diagonal-GMM log likelihood.','n_components=3; covariance_type=diag'),
}

_FACTORIES: Dict[str, Callable[[], Any]] = {
    'knn': KNNDistanceDetector,
    'avg_knn': AvgKNNDistanceDetector,
    'lof': LOFDetector,
    'iforest': IsolationForestDetector,
    'pca': PCADetector,
    'ocsvm': OneClassSVMDetector,
    'kmeans': KMeansDistanceDetector,
    'gmm': GaussianMixtureDetector,
}
DEFAULT_DETECTORS: List[str] = list(DETECTOR_SPECS)
EXCLUDED_METHODS = {'ecod','feod','efrod','rcod','frod'}

def make_detector(name: str) -> Any:
    key=name.lower()
    if key in EXCLUDED_METHODS:
        raise ValueError(f'{key} is excluded by SynOD-Atlas open-source benchmark policy')
    if key not in _FACTORIES:
        raise ValueError(f'Unknown detector {name!r}')
    return _FACTORIES[key]()

def run_detector(name: str, X: Array, *, contamination: float | None = None, random_state: int = 1) -> DetectorRun:
    """Run a detector. `contamination` is accepted for API compatibility but ignored."""
    start=perf_counter()
    try:
        scores=np.asarray(make_detector(name).fit_score(X, random_state=random_state),dtype=float).ravel()
        if len(scores)!=len(X) or not np.all(np.isfinite(scores)):
            raise RuntimeError('invalid anomaly scores')
        return DetectorRun(name,'ok',scores,perf_counter()-start)
    except Exception as exc:
        return DetectorRun(name,'error',None,perf_counter()-start,repr(exc))

def detector_specs_frame(detectors: Iterable[str] | None=None):
    import pandas as pd
    names=list(detectors) if detectors is not None else list(DETECTOR_SPECS)
    return pd.DataFrame([{**DETECTOR_SPECS[n].__dict__} for n in names])
