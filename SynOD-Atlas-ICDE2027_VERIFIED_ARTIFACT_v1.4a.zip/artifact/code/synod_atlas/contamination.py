"""Contamination-mismatch evaluation for SynOD-Atlas v1.4-DMKD.

The main benchmark evaluates detectors with top-k thresholding at the true
synthetic contamination. In practice, the true contamination level is usually
unknown. This module recomputes threshold-based metrics under alternative
assumed contamination values while preserving the same raw anomaly scores.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Sequence

import numpy as np
import pandas as pd

from .detectors import DEFAULT_DETECTORS, run_detector
from .evaluation import compute_metrics
from .generators import generate_dataset
from .validation import assert_valid_dataset


@dataclass(frozen=True)
class MismatchGrid:
    """Configuration for a contamination-mismatch experiment."""

    true_contaminations: Sequence[float]
    assumed_contaminations: Sequence[float]


def _mismatch_mode(true_pi: float, assumed_pi: float, tol: float = 1e-12) -> str:
    """Name the thresholding regime for easier analysis."""
    if abs(true_pi - assumed_pi) <= tol:
        return "matched"
    if assumed_pi < true_pi:
        return "underestimated"
    return "overestimated"


def evaluate_scores_under_mismatch(
    *,
    y_true: np.ndarray,
    scores: np.ndarray,
    assumed_contaminations: Iterable[float],
) -> pd.DataFrame:
    """Evaluate one score vector for several assumed contamination levels."""
    rows: List[dict] = []
    true_pi = float(np.mean(np.asarray(y_true).astype(int) == 1))
    for assumed_pi in assumed_contaminations:
        metrics = compute_metrics(y_true, scores, threshold_contamination=float(assumed_pi))
        metrics["true_contamination"] = true_pi
        metrics["assumed_contamination"] = float(assumed_pi)
        metrics["mismatch_mode"] = _mismatch_mode(true_pi, float(assumed_pi))
        metrics["contamination_ratio"] = float(assumed_pi) / max(true_pi, 1e-12)
        rows.append(metrics)
    return pd.DataFrame(rows)


def run_generated_mismatch_experiment(
    *,
    n_samples: int,
    families: Iterable[str],
    dimensions: Iterable[int],
    true_contaminations: Iterable[float],
    assumed_contaminations: Iterable[float],
    difficulties: Iterable[str],
    seeds: Iterable[int],
    detectors: Iterable[str] | None = None,
    output_dir: str | None = None,
    save_scores: bool = False,
) -> pd.DataFrame:
    """Generate datasets and compute contamination-mismatch metrics.

    Detectors are fitted/scored once per dataset. The same scores are then
    thresholded under each assumed contamination level. Ranking metrics such as
    ROC-AUC and Average Precision do not change across assumed contamination;
    threshold metrics such as precision, recall, F1, MCC and balanced accuracy do.
    """
    from pathlib import Path

    detector_list = list(detectors) if detectors is not None else list(DEFAULT_DETECTORS)
    output_path = Path(output_dir) if output_dir is not None else None
    if output_path is not None:
        output_path.mkdir(parents=True, exist_ok=True)
        if save_scores:
            (output_path / "scores").mkdir(parents=True, exist_ok=True)

    rows: List[dict] = []
    metadata_rows: List[dict] = []
    for family_id in families:
        for d in dimensions:
            for true_pi in true_contaminations:
                for difficulty in difficulties:
                    for seed in seeds:
                        X, y, meta = generate_dataset(
                            family_id=family_id,
                            n_samples=n_samples,
                            n_features=int(d),
                            contamination=float(true_pi),
                            difficulty=str(difficulty),
                            seed=int(seed),
                        )
                        assert_valid_dataset(X, y, meta)
                        metadata_rows.append(meta)
                        for detector in detector_list:
                            run = run_detector(detector, X, contamination=float(true_pi), random_state=int(seed))
                            base = {
                                "dataset_id": meta["dataset_id"],
                                "family_id": meta["family_id"],
                                "family_name": meta["family_name"],
                                "n_samples": meta["n_samples"],
                                "n_features": meta["n_features"],
                                "difficulty": meta["difficulty"],
                                "seed": meta["seed"],
                                "detector": detector,
                                "status": run.status,
                                "runtime_sec": run.runtime_sec,
                                "error": run.error,
                            }
                            if run.status != "ok" or run.scores is None:
                                for assumed_pi in assumed_contaminations:
                                    err_row = dict(base)
                                    err_row.update({
                                        "true_contamination": float(true_pi),
                                        "assumed_contamination": float(assumed_pi),
                                        "mismatch_mode": _mismatch_mode(float(true_pi), float(assumed_pi)),
                                        "rank_quality": np.nan,
                                        "balanced_accuracy": np.nan,
                                        "precision": np.nan,
                                        "recall": np.nan,
                                        "f1": np.nan,
                                        "mcc": np.nan,
                                        "roc_auc": np.nan,
                                        "average_precision": np.nan,
                                    })
                                    rows.append(err_row)
                                continue
                            if output_path is not None and save_scores:
                                score_file = output_path / "scores" / f"{meta['dataset_id']}__{detector}.csv"
                                np.savetxt(score_file, run.scores, delimiter=",", fmt="%.8g")
                            mismatch_df = evaluate_scores_under_mismatch(
                                y_true=y,
                                scores=run.scores,
                                assumed_contaminations=assumed_contaminations,
                            )
                            for rec in mismatch_df.to_dict(orient="records"):
                                out = dict(base)
                                out.update(rec)
                                rows.append(out)

    result = pd.DataFrame(rows)
    if output_path is not None:
        result.to_csv(output_path / "contamination_mismatch_metrics.csv", index=False)
        pd.DataFrame(metadata_rows).drop_duplicates("dataset_id").to_csv(
            output_path / "mismatch_datasets_metadata.csv", index=False
        )
    return result


def summarize_mismatch(metrics_df: pd.DataFrame) -> pd.DataFrame:
    """Summarize mismatch sensitivity by detector and mismatch mode."""
    ok = metrics_df[metrics_df["status"].eq("ok")].copy() if "status" in metrics_df.columns else metrics_df.copy()
    return ok.groupby(["detector", "mismatch_mode"], dropna=False).agg(
        mean_rank_quality=("rank_quality", "mean"),
        mean_balanced_accuracy=("balanced_accuracy", "mean"),
        mean_precision=("precision", "mean"),
        mean_recall=("recall", "mean"),
        mean_f1=("f1", "mean"),
        mean_mcc=("mcc", "mean"),
        mean_average_precision=("average_precision", "mean"),
        n_runs=("dataset_id", "count"),
    ).reset_index().sort_values(["detector", "mismatch_mode"])


def mismatch_loss_table(metrics_df: pd.DataFrame, metric: str = "f1") -> pd.DataFrame:
    """Compute loss relative to matched contamination for each detector/family.

    The output compares overestimated and underestimated contamination settings
    against the matched setting. Positive loss means performance deterioration.
    """
    ok = metrics_df[metrics_df["status"].eq("ok")].copy() if "status" in metrics_df.columns else metrics_df.copy()
    group_cols = ["dataset_id", "detector"]
    matched = ok[ok["mismatch_mode"].eq("matched")][group_cols + [metric]].rename(columns={metric: f"matched_{metric}"})
    merged = ok.merge(matched, on=group_cols, how="left")
    merged[f"{metric}_loss_vs_matched"] = merged[f"matched_{metric}"] - merged[metric]
    return merged.groupby(["detector", "family_id", "mismatch_mode"], dropna=False).agg(
        mean_loss=(f"{metric}_loss_vs_matched", "mean"),
        median_loss=(f"{metric}_loss_vs_matched", "median"),
        n_runs=("dataset_id", "count"),
    ).reset_index()
