"""Evaluation and chance-normalized Dataset Difficulty Index for v1.4-DMKD."""
from __future__ import annotations
from typing import Dict, Iterable
import numpy as np
import pandas as pd
from sklearn.metrics import (average_precision_score, balanced_accuracy_score, f1_score,
    matthews_corrcoef, precision_score, recall_score, roc_auc_score)

PRINCIPLES={
    'knn':'distance','avg_knn':'distance','lof':'local_density','iforest':'isolation',
    'pca':'projection','ocsvm':'boundary','kmeans':'clustering','gmm':'probabilistic_density'}

def binary_predictions_from_scores(scores, contamination):
    scores=np.asarray(scores,float); n=len(scores); k=max(1,min(n-1,int(round(contamination*n))))
    idx=np.argpartition(scores,-k)[-k:]; y=np.zeros(n,dtype=int); y[idx]=1; return y

def _clip01(x): return float(np.clip(x,0.,1.))

def normalized_rank_components(roc_auc: float, ap: float, pi: float):
    auc_n=_clip01((roc_auc-0.5)/0.5) if np.isfinite(roc_auc) else np.nan
    ap_n=_clip01((ap-pi)/(1.-pi+1e-12)) if np.isfinite(ap) else np.nan
    return auc_n,ap_n

def compute_metrics(y_true, scores, *, threshold_contamination=None)->Dict[str,float]:
    y=np.asarray(y_true,int); s=np.asarray(scores,float); pi=float(y.mean())
    threshold_pi=pi if threshold_contamination is None else float(threshold_contamination)
    yp=binary_predictions_from_scores(s,threshold_pi); k=max(1,int(y.sum()))
    order=np.argsort(s)[::-1][:k]
    roc=float(roc_auc_score(y,s)); ap=float(average_precision_score(y,s))
    auc_n,ap_n=normalized_rank_components(roc,ap,pi)
    ba=float(balanced_accuracy_score(y,yp)); f1=float(f1_score(y,yp,zero_division=0)); mcc=float(matthews_corrcoef(y,yp))
    # Chance-normalized threshold components are auxiliary robustness measures only.
    ba_n=_clip01((ba-.5)/.5); f1_n=_clip01((f1-pi)/(1-pi+1e-12)); mcc_n=_clip01(max(0.,mcc))
    return {
        'n_samples':float(len(y)),'n_anomaly':float(y.sum()),'contamination_true':pi,'threshold_contamination':threshold_pi,
        'balanced_accuracy':ba,'precision':float(precision_score(y,yp,zero_division=0)),
        'recall':float(recall_score(y,yp,zero_division=0)),'f1':f1,'mcc':mcc,
        'roc_auc':roc,'average_precision':ap,
        'precision_at_k':float(y[order].mean()), 'recall_at_k':float(y[order].sum()/max(1,y.sum())),
        'auc_norm':auc_n,'ap_norm':ap_n,'ba_norm':ba_n,'f1_norm':f1_n,'mcc_norm':mcc_n,
        'rank_quality':float(np.nanmean([auc_n,ap_n])),
        'composite_quality':float(np.nanmean([auc_n,ap_n,ba_n,f1_n,mcc_n])),
    }

def _principle_dataset_table(metrics_df: pd.DataFrame, value: str):
    ok=metrics_df[metrics_df.status.eq('ok')].copy()
    ok['principle']=ok['detector'].map(PRINCIPLES)
    return ok.groupby(['dataset_id','principle'],as_index=False)[value].mean()

def difficulty_variants(metrics_df: pd.DataFrame)->pd.DataFrame:
    """Return primary and alternative dataset-level DI definitions.

    Primary DI is rank-based, chance-normalized, and principle-balanced.
    """
    datasets=metrics_df['dataset_id'].drop_duplicates().tolist(); rows=[]
    for ds in datasets:
        g=metrics_df[(metrics_df.dataset_id==ds)&(metrics_df.status=='ok')].copy(); g['principle']=g.detector.map(PRINCIPLES)
        pg=g.groupby('principle').agg(rank_quality=('rank_quality','mean'),auc_norm=('auc_norm','mean'),ap_norm=('ap_norm','mean'),composite_quality=('composite_quality','mean')).reset_index()
        row={'dataset_id':ds,
             'DI_primary':1-float(pg.rank_quality.mean()),
             'DI_auc':1-float(pg.auc_norm.mean()),
             'DI_ap':1-float(pg.ap_norm.mean()),
             'DI_composite_pb':1-float(pg.composite_quality.mean()),
             'DI_rank_unbalanced':1-float(g.rank_quality.mean()),
             'n_principles':int(pg.principle.nunique()), 'n_detectors_ok':int(len(g)),
             'selective_difficulty':float(pg.rank_quality.std(ddof=0))}
        rows.append(row)
    return pd.DataFrame(rows)

def dataset_difficulty_index(metrics_df: pd.DataFrame)->pd.DataFrame:
    out=difficulty_variants(metrics_df).copy()
    out['difficulty_index']=out['DI_primary']
    return out

def method_summary(metrics_df: pd.DataFrame)->pd.DataFrame:
    ok=metrics_df[metrics_df.status.eq('ok')].copy()
    return ok.groupby('detector',as_index=False).agg(mean_rank_quality=('rank_quality','mean'),mean_roc_auc=('roc_auc','mean'),mean_average_precision=('average_precision','mean'),mean_runtime_sec=('runtime_sec','mean'),n_runs=('dataset_id','count')).sort_values('mean_rank_quality',ascending=False)

def family_method_matrix(metrics_df: pd.DataFrame,value='rank_quality'):
    return metrics_df[metrics_df.status.eq('ok')].pivot_table(index='family_id',columns='detector',values=value,aggfunc='mean')
