"""Visualization helpers for SynOD-Atlas."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

import matplotlib.pyplot as plt
import numpy as np

from .generators import generate_dataset


def plot_2d_dataset(X: np.ndarray, y: np.ndarray, title: str, output_path: str | Path | None = None) -> None:
    """Plot a single 2D dataset."""
    if X.shape[1] < 2:
        raise ValueError("X must have at least two columns")
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.scatter(X[y == 0, 0], X[y == 0, 1], s=10, alpha=0.65, label="normal")
    ax.scatter(X[y == 1, 0], X[y == 1, 1], s=18, alpha=0.90, label="anomaly", marker="x")
    ax.set_title(title)
    ax.set_xlabel("x1")
    ax.set_ylabel("x2")
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()
    if output_path is not None:
        fig.savefig(output_path, dpi=220)
        plt.close(fig)
    else:
        plt.show()


def plot_family_atlas(
    output_path: str | Path,
    *,
    families: Sequence[str] | None = None,
    n_samples: int = 700,
    contamination: float = 0.08,
    difficulty: str = "hard",
    seed: int = 7,
) -> None:
    """Create a compact visual atlas for d=2 versions of the families."""
    if families is None:
        families = [f"F{i:02d}" for i in range(1, 11)]

    cols = 5
    rows = int(np.ceil(len(families) / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 3.2, rows * 3.0))
    axes = np.array(axes).reshape(-1)

    for ax, family in zip(axes, families):
        X, y, meta = generate_dataset(
            family,
            n_samples=n_samples,
            n_features=2,
            contamination=contamination,
            difficulty=difficulty,
            seed=seed,
            scale=True,
            shuffle=True,
        )
        ax.scatter(X[y == 0, 0], X[y == 0, 1], s=7, alpha=0.62)
        ax.scatter(X[y == 1, 0], X[y == 1, 1], s=16, alpha=0.92, marker="x")
        ax.set_title(f"{family}: {meta['family_short']}")
        ax.set_xticks([])
        ax.set_yticks([])

    for ax in axes[len(families):]:
        ax.axis("off")

    fig.suptitle("SynOD-Atlas visual anomaly families", y=1.02, fontsize=14)
    fig.tight_layout()
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=240, bbox_inches="tight")
    plt.close(fig)
