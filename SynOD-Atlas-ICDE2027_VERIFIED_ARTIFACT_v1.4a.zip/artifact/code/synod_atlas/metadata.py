"""Metadata utilities for SynOD-Atlas."""

from __future__ import annotations

from typing import Any, Dict, Iterable, List

import numpy as np
import pandas as pd


def flatten_metadata(metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten metadata values into CSV-friendly scalar/string fields."""
    flat: Dict[str, Any] = {}
    for key, value in metadata.items():
        if isinstance(value, np.ndarray):
            if value.ndim == 1 and value.size <= 20:
                flat[key] = ";".join(map(str, value.tolist()))
            else:
                flat[key] = f"array_shape={value.shape}"
        elif isinstance(value, (list, tuple)):
            if len(value) <= 20 and not any(isinstance(v, (list, tuple, dict, np.ndarray)) for v in value):
                flat[key] = ";".join(map(str, value))
            else:
                flat[key] = f"list_len={len(value)}"
        elif isinstance(value, dict):
            flat[key] = f"dict_keys={','.join(map(str, value.keys()))}"
        elif isinstance(value, (np.integer,)):
            flat[key] = int(value)
        elif isinstance(value, (np.floating,)):
            flat[key] = float(value)
        else:
            flat[key] = value
    return flat


def metadata_frame(records: Iterable[Dict[str, Any]]) -> pd.DataFrame:
    """Convert metadata records to a DataFrame."""
    return pd.DataFrame([flatten_metadata(r) for r in records])
