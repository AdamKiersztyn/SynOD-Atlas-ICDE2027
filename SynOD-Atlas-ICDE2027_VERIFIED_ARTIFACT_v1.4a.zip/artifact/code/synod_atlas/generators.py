"""Synthetic data generators for SynOD-Atlas v1.4-DMKD.

Each generator returns X, y, metadata. Labels use 0 for normal observations
and 1 for anomalies.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Tuple

import numpy as np

from .utils import (
    make_base_metadata,
    orthonormal_embedding_matrix,
    sample_uniform_inside_ball,
    sample_unit_vector,
    sample_unit_vectors,
    shuffle_dataset,
    split_normal_anomaly_counts,
    standardize,
)

Array = np.ndarray
GeneratorReturn = Tuple[Array, Array, Dict[str, Any]]

VALID_DIFFICULTIES = {"easy", "medium", "hard", "extreme"}


FAMILY_NAMES = {
    "F01": ("Global Shift Anomalies", "global"),
    "F02": ("Correlation Break Anomalies", "corrbreak"),
    "F03": ("Multimodal Normality", "multimodal"),
    "F04": ("Unequal Density Anomalies", "density"),
    "F05": ("Clustered Anomalies", "clustered"),
    "F06": ("Subspace Anomalies", "subspace"),
    "F07": ("Irrelevant Feature Masking", "masking"),
    "F08": ("Manifold Anomalies", "manifold"),
    "F09": ("Boundary Anomalies", "boundary"),
    "F10": ("Rare Normal vs True Anomaly", "rare"),
}


def _finish_dataset(
    X_norm: Array,
    X_anom: Array,
    metadata: Dict[str, Any],
    *,
    rng: np.random.Generator,
    scale: bool,
    shuffle: bool,
) -> GeneratorReturn:
    y_norm = np.zeros(X_norm.shape[0], dtype=int)
    y_anom = np.ones(X_anom.shape[0], dtype=int)
    X = np.vstack([X_norm, X_anom])
    y = np.concatenate([y_norm, y_anom])

    metadata["raw_mean_norm"] = float(np.linalg.norm(X.mean(axis=0)))
    metadata["raw_std_mean"] = float(X.std(axis=0).mean())

    if scale:
        X, scaling_metadata = standardize(X)
        metadata.update(scaling_metadata)
    else:
        metadata.update({"scaled": False, "scaling": "none", "constant_columns": []})

    if shuffle:
        X, y, idx = shuffle_dataset(X, y, rng)
        metadata["shuffled"] = True
        metadata["shuffle_indices_saved"] = False
    else:
        metadata["shuffled"] = False

    return X.astype(float), y.astype(int), metadata


def _check_common_inputs(n_samples: int, n_features: int, contamination: float, difficulty: str) -> None:
    if n_samples < 20:
        raise ValueError("n_samples should be at least 20 for meaningful synthetic anomalies")
    if n_features < 2:
        raise ValueError("n_features must be at least 2")
    if difficulty not in VALID_DIFFICULTIES:
        raise ValueError(f"difficulty must be one of {sorted(VALID_DIFFICULTIES)}")
    split_normal_anomaly_counts(n_samples, contamination)


# -----------------------------------------------------------------------------
# F01 Global shift
# -----------------------------------------------------------------------------

def generate_F01(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    delta_map = {"easy": 6.0, "medium": 4.0, "hard": 2.5, "extreme": 1.5}
    delta = delta_map[difficulty]
    direction = sample_unit_vector(n_features, rng)

    X_norm = rng.normal(0.0, 1.0, size=(n_normal, n_features))
    X_anom = rng.normal(0.0, 1.0, size=(n_anomaly, n_features)) + delta * direction

    name, short = FAMILY_NAMES["F01"]
    metadata = make_base_metadata(
        family_id="F01", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
    )
    metadata.update({
        "anomaly_type": "global_mean_shift",
        "shift_delta": delta,
        "shift_direction": direction,
        "covariance_type": "identity",
        "expected_failure": "low",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F02 Correlation break
# -----------------------------------------------------------------------------

def _block_slices(d: int, target_block_size: int = 5) -> List[np.ndarray]:
    n_blocks = max(1, int(np.ceil(d / target_block_size)))
    indices = np.arange(d)
    return [block for block in np.array_split(indices, n_blocks) if len(block) > 0]


def _generate_block_correlated(n: int, d: int, blocks: List[np.ndarray], rng: np.random.Generator, sigma: float) -> Array:
    X = np.zeros((n, d), dtype=float)
    for block in blocks:
        z = rng.normal(0.0, 1.0, size=(n, 1))
        loadings = rng.uniform(0.8, 1.2, size=(1, len(block)))
        eps = rng.normal(0.0, sigma, size=(n, len(block)))
        X[:, block] = z @ loadings + eps
    return X


def generate_F02(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"sigma": 0.15, "anom_sigma": 1.50, "n_corrupt": 3, "flip": True},
        "medium": {"sigma": 0.20, "anom_sigma": 1.00, "n_corrupt": 2, "flip": True},
        "hard": {"sigma": 0.25, "anom_sigma": 0.70, "n_corrupt": 1, "flip": True},
        "extreme": {"sigma": 0.30, "anom_sigma": 0.45, "n_corrupt": 1, "flip": False},
    }[difficulty]

    blocks = _block_slices(n_features, target_block_size=max(2, min(8, n_features // 4 or 2)))
    X_norm = _generate_block_correlated(n_normal, n_features, blocks, rng, sigma=params["sigma"])
    X_anom = _generate_block_correlated(n_anomaly, n_features, blocks, rng, sigma=params["sigma"])

    n_corrupt = min(params["n_corrupt"], len(blocks))
    corrupt_idx = rng.choice(len(blocks), size=n_corrupt, replace=False)
    corrupted_blocks = []
    for bi in corrupt_idx:
        block = blocks[int(bi)]
        corrupted_blocks.append(block.tolist())
        if params["flip"] and len(block) >= 2:
            # Keep marginal ranges similar, but reverse relationships in the block.
            block_values = X_anom[:, block].copy()
            X_anom[:, block] = block_values[:, ::-1]
            X_anom[:, block[0]] *= -1.0
        X_anom[:, block] += rng.normal(0.0, params["anom_sigma"], size=(n_anomaly, len(block)))

    name, short = FAMILY_NAMES["F02"]
    metadata = make_base_metadata(
        family_id="F02", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
    )
    metadata.update({
        "anomaly_type": "dependency_violation",
        "n_blocks": len(blocks),
        "block_sizes": [len(b) for b in blocks],
        "corrupted_blocks": corrupted_blocks,
        "normal_noise_sigma": params["sigma"],
        "anomaly_noise_sigma": params["anom_sigma"],
        "correlation_break_index": float(params["anom_sigma"] + (1.0 if params["flip"] else 0.0)),
        "expected_failure": "marginal_detectors",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F03 Multimodal normality
# -----------------------------------------------------------------------------

def _sample_gmm(n: int, centers: Array, weights: Array, sigma: float, rng: np.random.Generator) -> Array:
    k = centers.shape[0]
    labels = rng.choice(k, size=n, p=weights)
    X = np.zeros((n, centers.shape[1]), dtype=float)
    for c in range(k):
        mask = labels == c
        if mask.any():
            X[mask] = rng.normal(centers[c], sigma, size=(mask.sum(), centers.shape[1]))
    return X


def generate_F03(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    """Multimodal normality with a fixed between-cluster anomaly mechanism.

    Difficulty changes overlap only; it does not change the anomaly mechanism.
    Center separation scales with sqrt(d) to avoid high-dimensional saturation.
    """
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    # Keep the same mechanism across difficulty levels. Normal cluster separation
    # grows as sqrt(d), while the anomalous bridge is shifted toward one legal
    # mode as difficulty increases. This creates more overlap without changing
    # the semantic anomaly type.
    params = {
        "easy": {"sep_factor": 1.15, "bridge_lambda": 0.50, "anom_sigma": 0.45},
        "medium": {"sep_factor": 1.50, "bridge_lambda": 0.50, "anom_sigma": 1.10},
        "hard": {"sep_factor": 1.50, "bridge_lambda": 0.50, "anom_sigma": 0.80},
        "extreme": {"sep_factor": 0.65, "bridge_lambda": 0.92, "anom_sigma": 0.42},
    }[difficulty]

    K = 3
    sep = params["sep_factor"] * np.sqrt(float(n_features))
    base_dirs = sample_unit_vectors(K, n_features, rng)
    centers = sep * base_dirs
    weights = np.array([0.60, 0.30, 0.10])
    normal_sigma = 0.80
    X_norm = _sample_gmm(n_normal, centers, weights, sigma=normal_sigma, rng=rng)

    lam = params["bridge_lambda"]
    # The same between-cluster bridge for all levels; lambda controls ambiguity.
    center_A = (1.0 - lam) * centers[0] + lam * centers[1]
    X_anom = rng.normal(center_A, params["anom_sigma"], size=(n_anomaly, n_features))

    name, short = FAMILY_NAMES["F03"]
    metadata = make_base_metadata(
        family_id="F03", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
    )
    metadata.update({
        "anomaly_type": "multimodal_between_cluster_bridge",
        "n_clusters_normal": K,
        "cluster_weights": weights,
        "cluster_centers": centers,
        "normal_cluster_sigma": normal_sigma,
        "anomaly_center": center_A,
        "anomaly_sigma": params["anom_sigma"],
        "multimodality_degree": K,
        "cluster_separation": float(sep),
        "bridge_lambda": float(lam),
        "expected_failure": "global_single_mode_detectors",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F04 Unequal density
# -----------------------------------------------------------------------------

def generate_F04(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    """Unequal-density normality with a fixed local-density anomaly mechanism.

    Medium and hard use the same mechanism. Hard anomalies are closer to the
    sparse legal mode and have a density more similar to it, increasing local
    ambiguity. The density contrast descriptor is stored on a log scale to
    remain numerically stable in high dimension.
    """
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"sparse_sigma": 1.45, "offset": 2.8, "anom_sigma": 0.65},
        "medium": {"sparse_sigma": 1.70, "offset": 1.35, "anom_sigma": 1.00},
        "hard": {"sparse_sigma": 1.70, "offset": 0.20, "anom_sigma": 1.00},
        "extreme": {"sparse_sigma": 2.00, "offset": 0.20, "anom_sigma": 1.75},
    }[difficulty]

    n_dense = int(0.75 * n_normal)
    n_sparse = n_normal - n_dense
    mu_dense = np.zeros(n_features)
    direction = sample_unit_vector(n_features, rng)
    # Scale cluster displacement weakly with d so the legal sparse mode remains
    # distinct without making the problem trivially separable in high d.
    sparse_center_distance = 2.5 + 0.15 * np.sqrt(float(n_features))
    mu_sparse = sparse_center_distance * direction
    mu_anom = mu_sparse + params["offset"] * direction

    X_dense = rng.normal(mu_dense, 0.50, size=(n_dense, n_features))
    X_sparse = rng.normal(mu_sparse, params["sparse_sigma"], size=(n_sparse, n_features))
    X_anom = rng.normal(mu_anom, params["anom_sigma"], size=(n_anomaly, n_features))
    X_norm = np.vstack([X_dense, X_sparse])

    name, short = FAMILY_NAMES["F04"]
    metadata = make_base_metadata(
        family_id="F04", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
    )
    log_density_ratio = float(n_features * np.log(params["sparse_sigma"] / 0.50))
    metadata.update({
        "anomaly_type": "local_density_contrast",
        "dense_cluster_size": n_dense,
        "sparse_cluster_size": n_sparse,
        "dense_sigma": 0.50,
        "sparse_sigma": params["sparse_sigma"],
        "anomaly_sigma": params["anom_sigma"],
        "anomaly_offset_from_sparse": params["offset"],
        "sparse_center_distance": float(sparse_center_distance),
        "log_density_ratio_proxy": log_density_ratio,
        "expected_failure": "density_methods_on_sparse_legal_regions",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F05 Clustered anomalies
# -----------------------------------------------------------------------------

def generate_F05(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"distance": 5.0, "sigma_A": 0.50},
        "medium": {"distance": 3.5, "sigma_A": 0.40},
        "hard": {"distance": 2.0, "sigma_A": 0.30},
        "extreme": {"distance": 1.2, "sigma_A": 0.25},
    }[difficulty]

    X_norm = rng.normal(0.0, 1.0, size=(n_normal, n_features))
    direction = sample_unit_vector(n_features, rng)
    mu_A = params["distance"] * direction
    X_anom = rng.normal(mu_A, params["sigma_A"], size=(n_anomaly, n_features))

    name, short = FAMILY_NAMES["F05"]
    metadata = make_base_metadata(
        family_id="F05", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
    )
    metadata.update({
        "anomaly_type": "compact_anomaly_cluster",
        "anomaly_cluster_center": mu_A,
        "anomaly_cluster_sigma": params["sigma_A"],
        "anomaly_compactness_proxy": float(1.0 / params["sigma_A"]),
        "distance_to_normal_center": params["distance"],
        "expected_failure": "local_density_methods",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F06 Subspace anomalies
# -----------------------------------------------------------------------------

def generate_F06(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
    fixed_k: int | None = None,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"alpha": 0.20, "delta": 4.0},
        "medium": {"alpha": 0.10, "delta": 3.0},
        "hard": {"alpha": 0.05, "delta": 2.5},
        "extreme": {"alpha": 0.01, "delta": 2.0},
    }[difficulty]

    k = int(fixed_k) if fixed_k is not None else max(1, int(np.floor(params["alpha"] * n_features)))
    k = max(1, min(n_features, k))
    anomaly_features = rng.choice(n_features, size=k, replace=False)

    X_norm = rng.normal(0.0, 1.0, size=(n_normal, n_features))
    X_anom = rng.normal(0.0, 1.0, size=(n_anomaly, n_features))
    X_anom[:, anomaly_features] += params["delta"]

    name, short = FAMILY_NAMES["F06"]
    metadata = make_base_metadata(
        family_id="F06", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
        extra_id=f"k{k:03d}",
    )
    metadata.update({
        "anomaly_type": "subspace_shift",
        "anomaly_subspace_dim": k,
        "anomaly_features": anomaly_features,
        "subspace_signal_ratio": float(k / n_features),
        "shift_delta": params["delta"],
        "irrelevant_feature_ratio": float((n_features - k) / n_features),
        "expected_failure": "full_space_distance_methods",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F07 Irrelevant feature masking
# -----------------------------------------------------------------------------

def _generate_noise(n: int, d: int, noise_type: str, rng: np.random.Generator) -> Array:
    if d <= 0:
        return np.empty((n, 0))
    if noise_type == "gaussian":
        return rng.normal(0.0, 1.0, size=(n, d))
    if noise_type == "uniform":
        return rng.uniform(-np.sqrt(3), np.sqrt(3), size=(n, d))
    if noise_type == "heavy_tail":
        return rng.standard_t(df=3, size=(n, d)) / np.sqrt(3)
    if noise_type == "sparse":
        mask = rng.binomial(1, 0.08, size=(n, d))
        values = rng.normal(0.0, 1.0, size=(n, d))
        return mask * values
    if noise_type == "correlated":
        blocks = _block_slices(d, target_block_size=max(2, min(8, d // 4 or 2)))
        return _generate_block_correlated(n, d, blocks, rng, sigma=0.25)
    raise ValueError("unknown noise_type")


def generate_F07(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
    noise_type: str = "gaussian",
    fixed_k: int | None = None,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"signal_ratio": 0.30, "delta": 4.0},
        "medium": {"signal_ratio": 0.15, "delta": 3.0},
        "hard": {"signal_ratio": 0.05, "delta": 2.5},
        "extreme": {"signal_ratio": 0.01, "delta": 2.0},
    }[difficulty]

    d_signal = int(fixed_k) if fixed_k is not None else max(1, int(np.floor(params["signal_ratio"] * n_features)))
    d_signal = max(1, min(d_signal, n_features))
    signal_features = rng.choice(n_features, size=d_signal, replace=False)
    all_features = np.arange(n_features)
    noise_features = np.setdiff1d(all_features, signal_features)
    d_noise = len(noise_features)

    X_norm = np.zeros((n_normal, n_features), dtype=float)
    X_anom = np.zeros((n_anomaly, n_features), dtype=float)

    X_norm[:, signal_features] = rng.normal(0.0, 1.0, size=(n_normal, d_signal))
    X_anom[:, signal_features] = rng.normal(params["delta"], 1.0, size=(n_anomaly, d_signal))

    X_norm[:, noise_features] = _generate_noise(n_normal, d_noise, noise_type, rng)
    X_anom[:, noise_features] = _generate_noise(n_anomaly, d_noise, noise_type, rng)

    name, short = FAMILY_NAMES["F07"]
    metadata = make_base_metadata(
        family_id="F07", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
        extra_id=f"s{d_signal:03d}_{noise_type}",
    )
    metadata.update({
        "anomaly_type": "masked_signal",
        "signal_features": signal_features,
        "noise_features": noise_features,
        "signal_dim": d_signal,
        "noise_dim": d_noise,
        "irrelevant_feature_ratio": float(d_noise / n_features),
        "noise_type": noise_type,
        "shift_delta": params["delta"],
        "expected_failure": "distance_methods_without_feature_selection",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F08 Manifold anomalies
# -----------------------------------------------------------------------------

def _latent_curve(z: Array) -> Array:
    """A simple nonlinear 2D latent manifold from one latent variable."""
    t = z[:, 0]
    return np.column_stack([t, np.sin(2.0 * t)])


def _embed_low_dim(Z: Array, d: int, rng: np.random.Generator) -> Array:
    """Embed a 1D/2D latent shape into d observed dimensions."""
    if d == Z.shape[1]:
        return Z.copy()
    W = orthonormal_embedding_matrix(Z.shape[1], d, rng)
    return Z @ W.T


def generate_F08(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"gamma": 3.0, "noise": 0.05},
        "medium": {"gamma": 2.0, "noise": 0.08},
        "hard": {"gamma": 1.0, "noise": 0.12},
        "extreme": {"gamma": 0.5, "noise": 0.18},
    }[difficulty]

    z_norm = rng.uniform(-3.0, 3.0, size=(n_normal, 1))
    latent_norm = _latent_curve(z_norm)
    X_norm = _embed_low_dim(latent_norm, n_features, rng)
    X_norm += rng.normal(0.0, params["noise"], size=X_norm.shape)

    z_anom = rng.uniform(-3.0, 3.0, size=(n_anomaly, 1))
    latent_anom = _latent_curve(z_anom)
    X_anom = _embed_low_dim(latent_anom, n_features, rng)

    direction = sample_unit_vector(n_features, rng)
    X_anom += params["gamma"] * direction
    X_anom += rng.normal(0.0, params["noise"], size=X_anom.shape)

    name, short = FAMILY_NAMES["F08"]
    metadata = make_base_metadata(
        family_id="F08", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
    )
    metadata.update({
        "anomaly_type": "off_manifold",
        "intrinsic_dim": 1,
        "embedding_dim": n_features,
        "manifold_type": "sinusoidal_curve_embedded",
        "manifold_noise": params["noise"],
        "manifold_deviation": params["gamma"],
        "expected_failure": "global_detectors_for_local_geometry",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F09 Boundary anomalies
# -----------------------------------------------------------------------------

def generate_F09(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
    boundary_shape: str = "ball",
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    margin_map = {"easy": 1.00, "medium": 0.50, "hard": 0.20, "extreme": 0.05}
    margin = margin_map[difficulty]
    R = 1.0

    if boundary_shape != "ball":
        raise ValueError("This release implements boundary_shape='ball'; ring/cube are not part of the Core")

    X_norm = sample_uniform_inside_ball(n_normal, n_features, R, rng)
    directions = sample_unit_vectors(n_anomaly, n_features, rng)
    radii = R + margin + rng.normal(0.0, max(margin / 5.0, 1e-4), size=n_anomaly)
    radii = np.maximum(radii, R + 1e-4)
    X_anom = directions * radii[:, None]

    name, short = FAMILY_NAMES["F09"]
    metadata = make_base_metadata(
        family_id="F09", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
        extra_id=boundary_shape,
    )
    metadata.update({
        "anomaly_type": "near_boundary_violation",
        "boundary_shape": boundary_shape,
        "boundary_radius": R,
        "boundary_margin": margin,
        "boundary_difficulty_index": float(1.0 / margin),
        "expected_failure": "methods_without_support_boundary_model",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


# -----------------------------------------------------------------------------
# F10 Rare normal vs true anomaly
# -----------------------------------------------------------------------------

def generate_F10(
    n_samples: int,
    n_features: int,
    contamination: float,
    difficulty: str,
    seed: int,
    *,
    scale: bool = True,
    shuffle: bool = True,
) -> GeneratorReturn:
    _check_common_inputs(n_samples, n_features, contamination, difficulty)
    rng = np.random.default_rng(seed)
    n_normal, n_anomaly = split_normal_anomaly_counts(n_samples, contamination)

    params = {
        "easy": {"rare_distance": 2.0, "anom_distance": 5.0, "rare_sigma": 0.8, "anom_sigma": 0.6},
        "medium": {"rare_distance": 3.0, "anom_distance": 3.5, "rare_sigma": 0.9, "anom_sigma": 0.7},
        "hard": {"rare_distance": 4.0, "anom_distance": 3.0, "rare_sigma": 1.1, "anom_sigma": 0.6},
        "extreme": {"rare_distance": 5.0, "anom_distance": 2.5, "rare_sigma": 1.3, "anom_sigma": 0.5},
    }[difficulty]

    rare_ratio = 0.05
    n_rare = max(1, int(np.floor(rare_ratio * n_normal)))
    n_main = n_normal - n_rare

    X_main = rng.normal(0.0, 1.0, size=(n_main, n_features))

    u_rare = sample_unit_vector(n_features, rng)
    u_anom = sample_unit_vector(n_features, rng)
    # Avoid identical directions, so rare normal and anomaly are distinct structures.
    if np.dot(u_rare, u_anom) > 0.8:
        u_anom = -u_anom

    mu_rare = params["rare_distance"] * u_rare
    mu_anom = params["anom_distance"] * u_anom

    X_rare = rng.normal(mu_rare, params["rare_sigma"], size=(n_rare, n_features))
    X_anom = rng.normal(mu_anom, params["anom_sigma"], size=(n_anomaly, n_features))
    X_norm = np.vstack([X_main, X_rare])

    name, short = FAMILY_NAMES["F10"]
    metadata = make_base_metadata(
        family_id="F10", family_name=name, family_short=short,
        n_samples=n_samples, n_features=n_features, contamination=contamination,
        difficulty=difficulty, seed=seed, n_normal=n_normal, n_anomaly=n_anomaly,
        extra_id=f"r{int(rare_ratio * 100):02d}",
    )
    metadata.update({
        "anomaly_type": "rare_normal_vs_true_anomaly",
        "rare_normal_ratio": rare_ratio,
        "n_rare_normal": n_rare,
        "n_main_normal": n_main,
        "rare_center": mu_rare,
        "anomaly_center": mu_anom,
        "rare_sigma": params["rare_sigma"],
        "anomaly_sigma": params["anom_sigma"],
        "rare_distance": params["rare_distance"],
        "anomaly_distance": params["anom_distance"],
        "rare_anomaly_distance_ratio": float(params["rare_distance"] / params["anom_distance"]),
        "density_inversion": bool(params["anom_sigma"] < params["rare_sigma"]),
        "expected_failure": "rarity_equals_anomaly_detectors",
    })
    return _finish_dataset(X_norm, X_anom, metadata, rng=rng, scale=scale, shuffle=shuffle)


GENERATORS: Dict[str, Callable[..., GeneratorReturn]] = {
    "F01": generate_F01,
    "F02": generate_F02,
    "F03": generate_F03,
    "F04": generate_F04,
    "F05": generate_F05,
    "F06": generate_F06,
    "F07": generate_F07,
    "F08": generate_F08,
    "F09": generate_F09,
    "F10": generate_F10,
}


def generate_dataset(
    family_id: str,
    n_samples: int = 1000,
    n_features: int = 50,
    contamination: float = 0.05,
    difficulty: str = "medium",
    seed: int = 1,
    *,
    scale: bool = True,
    shuffle: bool = True,
    **kwargs: Any,
) -> GeneratorReturn:
    """Generate one SynOD-Atlas dataset.

    Parameters are intentionally uniform across families. Family-specific options
    can be passed through kwargs, e.g. noise_type='correlated' for F07.
    """
    family_id = family_id.upper()
    if family_id not in GENERATORS:
        raise ValueError(f"Unknown family_id={family_id}. Available: {sorted(GENERATORS)}")
    return GENERATORS[family_id](
        n_samples=n_samples,
        n_features=n_features,
        contamination=contamination,
        difficulty=difficulty,
        seed=seed,
        scale=scale,
        shuffle=shuffle,
        **kwargs,
    )
