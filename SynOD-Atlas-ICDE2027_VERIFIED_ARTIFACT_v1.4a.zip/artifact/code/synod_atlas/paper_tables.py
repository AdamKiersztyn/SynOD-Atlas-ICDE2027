"""Paper-oriented tables for SynOD-Atlas v1.4-DMKD."""

from __future__ import annotations

from pathlib import Path
from typing import Dict

import pandas as pd

from .detectors import detector_specs_frame
from .profiles import family_hardness_profile


FAMILY_TABLE = pd.DataFrame([
    ["F01", "Global shift", "Single Gaussian cloud", "Mean-shifted anomaly cloud", "global separability"],
    ["F02", "Correlation break", "Block-correlated features", "Broken feature dependencies", "dependency violation"],
    ["F03", "Multimodal normality", "Gaussian mixture", "Between-cluster bridge anomalies", "multimodal normality"],
    ["F04", "Unequal density", "Dense and sparse normal regions", "Anomalies near sparse normality", "local-density contrast"],
    ["F05", "Clustered anomalies", "Main normal cloud", "Compact anomalous cluster", "collective point anomalies"],
    ["F06", "Subspace anomalies", "Full-dimensional normal noise", "Shift in a small subspace", "subspace signal masking"],
    ["F07", "Irrelevant masking", "Signal plus noise features", "Anomaly signal masked by irrelevant features", "curse of dimensionality"],
    ["F08", "Manifold anomalies", "Low-dimensional manifold", "Off-manifold deviation", "local geometry"],
    ["F09", "Boundary anomalies", "Compact bounded domain", "Near-boundary violations", "soft decision boundary"],
    ["F10", "Rare normal vs anomaly", "Main and rare legal modes", "True anomaly competing with rare normality", "rarity vs abnormality"],
], columns=["family_id", "family_name", "normal_structure", "anomaly_mechanism", "main_difficulty_axis"])


METRIC_TABLE = pd.DataFrame([
    ["Balanced Accuracy", "threshold", "no", "diagnostic threshold metric"],
    ["Precision", "threshold", "no", "reported separately; crucial under low contamination"],
    ["Recall", "threshold", "no", "reported separately; measures anomaly coverage"],
    ["F1", "threshold", "no", "diagnostic threshold metric"],
    ["MCC", "threshold", "no", "diagnostic threshold metric"],
    ["ROC-AUC", "ranking", "yes", "chance-normalized component of primary DI"],
    ["Average Precision", "ranking", "yes", "chance-normalized against contamination baseline"],
    ["Precision@k", "ranking/top-k", "no", "operational top-list quality"],
    ["Runtime", "technical", "no", "reported as scalability evidence"],
    ["Status", "technical", "no", "records execution failures without interrupting benchmark"],
], columns=["metric", "type", "included_in_DI", "role"])


def build_tables(
    *,
    metrics_path: str | Path | None = None,
    difficulty_path: str | Path | None = None,
    output_dir: str | Path,
) -> Dict[str, pd.DataFrame]:
    """Create CSV and Markdown paper tables."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    tables: Dict[str, pd.DataFrame] = {
        "table_1_synthetic_families": FAMILY_TABLE.copy(),
        "table_2_metrics": METRIC_TABLE.copy(),
        "table_3_detectors": detector_specs_frame(),
    }

    if metrics_path is not None:
        metrics = pd.read_csv(metrics_path)
        method_summary = metrics[metrics["status"].eq("ok")].groupby("detector", dropna=False).agg(
            mean_rank_quality=("rank_quality", "mean"),
            mean_roc_auc=("roc_auc", "mean"),
            mean_average_precision=("average_precision", "mean"),
            mean_f1=("f1", "mean"),
            mean_runtime_sec=("runtime_sec", "mean"),
            n_runs=("dataset_id", "count"),
        ).reset_index().sort_values("mean_rank_quality", ascending=False)
        tables["table_4_method_summary"] = method_summary
        tables["table_5_family_method_profiles"] = family_hardness_profile(metrics)

    if difficulty_path is not None and metrics_path is not None:
        difficulty = pd.read_csv(difficulty_path)
        metrics = pd.read_csv(metrics_path)
        info = metrics[["dataset_id", "family_id", "n_features", "contamination", "difficulty"]].drop_duplicates()
        diff = difficulty.merge(info, on="dataset_id", how="left")
        family_diff = diff.groupby("family_id", dropna=False).agg(
            mean_DI=("difficulty_index", "mean"),
            std_DI=("difficulty_index", "std"),
            mean_selective_difficulty=("selective_difficulty", "mean"),
            n_datasets=("dataset_id", "count"),
        ).reset_index().sort_values("mean_DI", ascending=False)
        tables["table_6_family_difficulty_ranking"] = family_diff

    for name, df in tables.items():
        df.to_csv(out / f"{name}.csv", index=False)
        with open(out / f"{name}.md", "w", encoding="utf-8") as f:
            f.write(df.to_markdown(index=False))
            f.write("\n")
    return tables
