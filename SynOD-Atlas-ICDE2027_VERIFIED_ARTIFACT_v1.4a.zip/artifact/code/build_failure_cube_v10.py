"""Build a constrained, provenance-bearing v1.4 Failure Cube."""
from pathlib import Path
import argparse,hashlib,sqlite3
import pandas as pd
PRINCIPLES={'knn':'distance','avg_knn':'distance','lof':'local_density','iforest':'isolation','pca':'projection_residual','ocsvm':'support_boundary','kmeans':'clustering_distance','gmm':'parametric_density','hbos':'histogram','copod':'copula_tail','loda':'random_projection','inne':'neighborhood_isolation','sampling':'sampled_distance'}
MEANINGS=['global shift','dependency break','multimodal normality','unequal density','clustered anomalies','subspace anomalies','irrelevant-feature masking','manifold departure','support-boundary violation','rare-normal ambiguity']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--artifact-root',default=str(Path(__file__).resolve().parents[1]));ap.add_argument('--output');a=ap.parse_args();root=Path(a.artifact_root);dest=Path(a.output) if a.output else root/'failure_cube.sqlite'
 d=pd.read_csv(root/'v21a_datasets_metadata.csv');r=pd.read_csv(root/'core_metrics.csv')
 assert len(d)==2100 and d.dataset_id.is_unique
 assert len(r)==27300 and not r.duplicated(['dataset_id','detector']).any()
 assert set(r.detector)==set(PRINCIPLES) and r.groupby('dataset_id').size().eq(13).all()
 assert set(r.dataset_id)==set(d.dataset_id)
 assert r[['roc_auc','average_precision','q']].apply(lambda s:s.between(-1e-12,1+1e-12).all()).all()
 dest.unlink(missing_ok=True);c=sqlite3.connect(dest);c.execute('PRAGMA foreign_keys=ON')
 d.to_sql('datasets',c,index=False);c.execute('CREATE UNIQUE INDEX dataset_key ON datasets(dataset_id)')
 c.executescript('''CREATE TABLE detectors(detector TEXT PRIMARY KEY,principle TEXT NOT NULL);
 CREATE TABLE mechanisms(family TEXT PRIMARY KEY,meaning TEXT NOT NULL);
 CREATE TABLE runs(dataset_id TEXT NOT NULL REFERENCES datasets(dataset_id),family TEXT NOT NULL REFERENCES mechanisms(family),d INTEGER NOT NULL,n INTEGER NOT NULL,pi REAL NOT NULL,stress REAL NOT NULL,seed INTEGER NOT NULL,detector TEXT NOT NULL REFERENCES detectors(detector),roc_auc REAL NOT NULL CHECK(roc_auc BETWEEN -1e-12 AND 1.000000000001),average_precision REAL NOT NULL CHECK(average_precision BETWEEN -1e-12 AND 1.000000000001),q REAL NOT NULL CHECK(q BETWEEN -1e-12 AND 1.000000000001),PRIMARY KEY(dataset_id,detector));
 CREATE TABLE provenance(path TEXT PRIMARY KEY,sha256 TEXT NOT NULL,release TEXT NOT NULL);''')
 c.executemany('INSERT INTO detectors VALUES (?,?)',PRINCIPLES.items());c.executemany('INSERT INTO mechanisms VALUES (?,?)',[(f'F{i+1:02d}',v) for i,v in enumerate(MEANINGS)])
 cols=['dataset_id','family','d','n','pi','stress','seed','detector','roc_auc','average_precision','q'];c.executemany('INSERT INTO runs VALUES (?,?,?,?,?,?,?,?,?,?,?)',r[cols].itertuples(index=False,name=None))
 for table,f in [('boundaries_tau030','boundary_bootstrap_tau030.csv'),('profile_morphology_tau030','profile_morphology_tau030.csv')]:
  x=pd.read_csv(root/'reproduced_analysis_v10'/f);assert len(x)==780 and not x.duplicated(['family','d','pi','detector']).any();x.to_sql(table,c,index=False);c.execute(f'CREATE UNIQUE INDEX {table}_key ON {table}(family,d,pi,detector)')
 for f in sorted(root.rglob('*')):
  if f.is_file() and (f.suffix in {'.py','.csv'} or f.name.startswith('requirements')):c.execute('INSERT INTO provenance VALUES (?,?,?)',(str(f.relative_to(root)),hashlib.sha256(f.read_bytes()).hexdigest(),'ICDE-v1.4-13-detectors'))
 c.executescript('''CREATE VIEW competence_tau030 AS SELECT family,d,pi,stress,detector,AVG(CASE WHEN q>=.30 THEN 1.0 ELSE 0.0 END) competence_probability FROM runs GROUP BY family,d,pi,stress,detector;
 CREATE VIEW detector_global_summary AS SELECT detector,COUNT(*) n_runs,AVG(q) mean_q,AVG(roc_auc) mean_auc,AVG(average_precision) mean_ap FROM runs GROUP BY detector;
 CREATE VIEW family_detector_competence AS SELECT family,detector,AVG(competence_volume) mean_competence_volume FROM profile_morphology_tau030 GROUP BY family,detector;
 CREATE VIEW incomplete_datasets AS SELECT d.dataset_id,COUNT(r.detector) n_runs FROM datasets d LEFT JOIN runs r USING(dataset_id) GROUP BY d.dataset_id HAVING COUNT(r.detector)<>13;''')
 assert not c.execute('PRAGMA foreign_key_check').fetchall();assert c.execute('SELECT COUNT(*) FROM incomplete_datasets').fetchone()[0]==0;assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.commit();c.close()
 print('PASS: 2100 datasets; 27300 runs; 13 detectors; 780 profiles; 780 boundary records; no integrity violations.')
if __name__=='__main__':main()
