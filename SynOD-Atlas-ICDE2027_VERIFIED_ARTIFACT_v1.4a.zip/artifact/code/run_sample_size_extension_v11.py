from __future__ import annotations
import sys,time,argparse
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from generators_v21 import generate_v21
from detectors_v21a import DEFAULT_DETECTORS,run_detector_v21a
from extra_detectors_pyod366 import EXTRA_DETECTORS,run_extra_detector
from synod_atlas.evaluation import compute_metrics

FAMILIES=['F01','F03','F04','F05','F07','F09','F10']
STRESSES=[0.0,1/3,2/3,1.0]
SEEDS=[1,2,3]
D=50; PI=.05
DETS=list(DEFAULT_DETECTORS)+list(EXTRA_DETECTORS)

def run_n(n,outdir):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    p=outdir/f'n{n}_metrics.csv'
    rows=[]; done=set()
    if p.exists() and p.stat().st_size>20:
        old=pd.read_csv(p)
        rows=old.to_dict('records')
        done={(r['family'],round(float(r['stress']),8),int(r['seed']),r['detector']) for _,r in old.iterrows()}
    t0=time.time(); added=0
    for fam in FAMILIES:
      for h in STRESSES:
       for seed in SEEDS:
        need=[det for det in DETS if (fam,round(float(h),8),seed,det) not in done]
        if not need: continue
        X,y,_=generate_v21(fam,n,D,PI,h,seed)
        for det in need:
          st=time.perf_counter(); status='ok'; err=''
          try:
            scores=(run_detector_v21a(det,X,random_state=seed).scores if det in DEFAULT_DETECTORS
                    else np.asarray(run_extra_detector(det,X,random_state=seed),float))
            z=compute_metrics(y,scores)
          except Exception as e:
            status='error';err=repr(e);z={'roc_auc':np.nan,'average_precision':np.nan,'rank_quality':np.nan}
          rows.append(dict(family=fam,d=D,n=n,pi=PI,stress=h,seed=seed,detector=det,status=status,
                           runtime_sec=time.perf_counter()-st,error=err,roc_auc=z['roc_auc'],
                           average_precision=z['average_precision'],q=z['rank_quality'],dataset_id=''))
          added+=1
        tmp=p.with_suffix('.tmp');pd.DataFrame(rows).to_csv(tmp,index=False);tmp.replace(p)
      print(f'n={n} {fam}: {len(rows)}/1092 errors={sum(r["status"]!="ok" for r in rows)} elapsed={time.time()-t0:.1f}s',flush=True)
    df=pd.DataFrame(rows)
    df.to_csv(p,index=False)
    print(f'DONE n={n} rows={len(df)} errors={(df.status!="ok").sum()} runtime_sum={df.runtime_sec.sum():.2f}s wall={time.time()-t0:.1f}s',flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,required=True);ap.add_argument('--out',required=True);a=ap.parse_args();run_n(a.n,a.out)
