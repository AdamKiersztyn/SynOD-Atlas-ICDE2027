"""SynOD-Atlas v2.1a lineage-preserving stress generators.

This module extends the hash-verified SynOD-Atlas v1.4 generator along seven
mechanism-specific stress coordinates. Exact historical anchors call the v1.4
generator directly. Intermediate points preserve the same random-call order and
mechanism semantics while changing only documented physical parameters.

The reported ICDE evaluation uses n=500, d in {10,50,100}, pi in {.05,.10},
seed in {1,...,5}. F06/F07 use a fixed five-dimensional signal subspace.
"""
from __future__ import annotations
from typing import Any, Dict, Tuple
import numpy as np

from synod_atlas.generators import (
    FAMILY_NAMES, generate_dataset as generate_v14,
    _finish_dataset, _block_slices, _generate_block_correlated, _sample_gmm,
    _generate_noise, _latent_curve, _embed_low_dim,
)
from synod_atlas.utils import (
    make_base_metadata, sample_unit_vector, sample_unit_vectors,
    sample_uniform_inside_ball, split_normal_anomaly_counts,
)

Array=np.ndarray
GeneratorReturn=Tuple[Array,Array,Dict[str,Any]]
STRESSES=(0.0,1/6,2/6,3/6,4/6,5/6,1.0)


def _nearest_stress(h: float) -> float:
    vals=np.asarray(STRESSES,float); i=int(np.argmin(np.abs(vals-float(h))))
    if abs(vals[i]-float(h))>1e-6:
        raise ValueError(f"stress must be one of {STRESSES}; got {h}")
    return float(vals[i])


def _tag(meta: Dict[str,Any], family: str, h: float, anchor: str|None) -> Dict[str,Any]:
    meta=dict(meta)
    meta['stress']=float(h)
    meta['stress_anchor']=anchor
    meta['generator_lineage']='SynOD-v1.4-exact-anchor' if anchor else 'SynOD-v1.4-lineage-interpolation'
    meta['family']=family
    meta['d']=int(meta['n_features']); meta['n']=int(meta['n_samples']); meta['pi']=float(meta['contamination'])
    return meta


def _call_anchor(family,n,d,pi,h,seed,difficulty,**kwargs):
    X,y,m=generate_v14(family,n_samples=n,n_features=d,contamination=pi,difficulty=difficulty,seed=seed,**kwargs)
    return X,y,_tag(m,family,h,difficulty)


def generate_v21(family: str,n: int=500,d: int=10,pi: float=.05,stress: float=0.0,seed: int=1,
                 *,scale: bool=True,shuffle: bool=True) -> GeneratorReturn:
    family=family.upper(); h=_nearest_stress(stress)
    # Exact anchors. F03 and F04 intentionally use only the ordered v1.4 anchors
    # documented in the paper; F06/F07 preserve fixed k=5.
    standard_anchors={0.0:'easy',2/6:'medium',4/6:'hard',1.0:'extreme'}
    if family in {'F01','F02','F05','F08','F09','F10'} and h in standard_anchors:
        return _call_anchor(family,n,d,pi,h,seed,standard_anchors[h],scale=scale,shuffle=shuffle)
    if family in {'F06','F07'} and h in standard_anchors:
        return _call_anchor(family,n,d,pi,h,seed,standard_anchors[h],fixed_k=5,scale=scale,shuffle=shuffle)
    if family=='F03' and h in {0.0,.5,1.0}:
        diff={0.0:'medium',.5:'hard',1.0:'extreme'}[h]
        return _call_anchor(family,n,d,pi,h,seed,diff,scale=scale,shuffle=shuffle)
    if family=='F04' and h in {0.0,1.0}:
        diff={0.0:'medium',1.0:'hard'}[h]
        return _call_anchor(family,n,d,pi,h,seed,diff,scale=scale,shuffle=shuffle)

    rng=np.random.default_rng(seed)
    n_normal,n_anomaly=split_normal_anomaly_counts(n,pi)
    diff=f"stress_{h:.6f}"

    if family=='F01':
        delta={1/6:5.0,.5:3.25,5/6:2.0}[h]
        direction=sample_unit_vector(d,rng)
        Xn=rng.normal(0,1,(n_normal,d)); Xa=rng.normal(0,1,(n_anomaly,d))+delta*direction
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly)
        m.update(anomaly_type='global_mean_shift',shift_delta=delta,shift_direction=direction,covariance_type='identity',expected_failure='low')

    elif family=='F02':
        pmap={1/6:(.175,1.25,2,True),.5:(.225,.85,1,True),5/6:(.275,.575,1,True)}
        sigma,anom_sigma,n_corrupt,flip=pmap[h]
        blocks=_block_slices(d,target_block_size=max(2,min(8,d//4 or 2)))
        Xn=_generate_block_correlated(n_normal,d,blocks,rng,sigma=sigma)
        Xa=_generate_block_correlated(n_anomaly,d,blocks,rng,sigma=sigma)
        n_corrupt=min(n_corrupt,len(blocks)); idx=rng.choice(len(blocks),size=n_corrupt,replace=False); corrupted=[]
        for bi in idx:
            block=blocks[int(bi)]; corrupted.append(block.tolist())
            if flip and len(block)>=2:
                vals=Xa[:,block].copy(); Xa[:,block]=vals[:,::-1]; Xa[:,block[0]]*=-1.0
            Xa[:,block]+=rng.normal(0,anom_sigma,size=(n_anomaly,len(block)))
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly)
        m.update(anomaly_type='dependency_violation',n_blocks=len(blocks),block_sizes=[len(b) for b in blocks],corrupted_blocks=corrupted,normal_noise_sigma=sigma,anomaly_noise_sigma=anom_sigma,correlation_break_index=float(anom_sigma+(1 if flip else 0)),n_corrupt=n_corrupt,flip=flip,expected_failure='marginal_detectors')

    elif family=='F03':
        # h in {1/6,2/6,4/6,5/6}; preserve v1.4 medium/hard/extreme path.
        if h < .5:
            sep_factor=1.5; lam=.5; anom_sigma={1/6:1.0,2/6:.9}[h]
        else:
            t=(h-.5)/.5
            sep_factor=1.5+t*(.65-1.5); lam=.5+t*(.92-.5); anom_sigma=.8+t*(.42-.8)
        K=3; sep=sep_factor*np.sqrt(float(d)); dirs=sample_unit_vectors(K,d,rng); centers=sep*dirs
        weights=np.array([.60,.30,.10]); normal_sigma=.80
        Xn=_sample_gmm(n_normal,centers,weights,normal_sigma,rng)
        center_A=(1-lam)*centers[0]+lam*centers[1]; Xa=rng.normal(center_A,anom_sigma,size=(n_anomaly,d))
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly)
        m.update(anomaly_type='multimodal_between_cluster_bridge',n_clusters_normal=K,cluster_weights=weights,cluster_centers=centers,normal_cluster_sigma=normal_sigma,anomaly_center=center_A,anomaly_sigma=anom_sigma,multimodality_degree=K,cluster_separation=float(sep),bridge_lambda=float(lam),expected_failure='global_single_mode_detectors')

    elif family=='F04':
        offset=1.35+(0.20-1.35)*h; sparse_sigma=1.70; anom_sigma=1.0
        n_dense=int(.75*n_normal); n_sparse=n_normal-n_dense; mu_dense=np.zeros(d); direction=sample_unit_vector(d,rng)
        sparse_dist=2.5+.15*np.sqrt(float(d)); mu_sparse=sparse_dist*direction; mu_anom=mu_sparse+offset*direction
        Xdense=rng.normal(mu_dense,.50,size=(n_dense,d)); Xsparse=rng.normal(mu_sparse,sparse_sigma,size=(n_sparse,d)); Xa=rng.normal(mu_anom,anom_sigma,size=(n_anomaly,d)); Xn=np.vstack([Xdense,Xsparse])
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly)
        m.update(anomaly_type='local_density_contrast',dense_cluster_size=n_dense,sparse_cluster_size=n_sparse,dense_sigma=.50,sparse_sigma=sparse_sigma,anomaly_sigma=anom_sigma,anomaly_offset_from_sparse=offset,sparse_center_distance=float(sparse_dist),log_density_ratio_proxy=float(d*np.log(sparse_sigma/.50)),expected_failure='density_methods_on_sparse_legal_regions')

    elif family=='F05':
        dist,sigma={1/6:(4.25,.45),.5:(2.75,.35),5/6:(1.60,.275)}[h]
        Xn=rng.normal(0,1,size=(n_normal,d)); direction=sample_unit_vector(d,rng); mu=dist*direction; Xa=rng.normal(mu,sigma,size=(n_anomaly,d))
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly)
        m.update(anomaly_type='compact_anomaly_cluster',anomaly_cluster_center=mu,anomaly_cluster_sigma=sigma,anomaly_compactness_proxy=float(1/sigma),distance_to_normal_center=dist,expected_failure='local_density_methods')

    elif family=='F06':
        delta={1/6:3.5,.5:2.75,5/6:2.25}[h]; k=5; feats=rng.choice(d,size=k,replace=False)
        Xn=rng.normal(0,1,size=(n_normal,d)); Xa=rng.normal(0,1,size=(n_anomaly,d)); Xa[:,feats]+=delta
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly,extra_id=f'k{k:03d}')
        m.update(anomaly_type='subspace_shift',anomaly_subspace_dim=k,anomaly_features=feats,subspace_signal_ratio=float(k/d),shift_delta=delta,irrelevant_feature_ratio=float((d-k)/d),expected_failure='full_space_distance_methods')

    elif family=='F07':
        delta={1/6:3.5,.5:2.75,5/6:2.25}[h]; k=5; signal=rng.choice(d,size=k,replace=False); noise=np.setdiff1d(np.arange(d),signal); dn=len(noise)
        Xn=np.zeros((n_normal,d)); Xa=np.zeros((n_anomaly,d)); Xn[:,signal]=rng.normal(0,1,size=(n_normal,k)); Xa[:,signal]=rng.normal(delta,1,size=(n_anomaly,k)); Xn[:,noise]=_generate_noise(n_normal,dn,'gaussian',rng); Xa[:,noise]=_generate_noise(n_anomaly,dn,'gaussian',rng)
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly,extra_id=f's{k:03d}_gaussian')
        m.update(anomaly_type='masked_signal',signal_features=signal,noise_features=noise,signal_dim=k,noise_dim=dn,irrelevant_feature_ratio=float(dn/d),noise_type='gaussian',shift_delta=delta,expected_failure='distance_methods_without_feature_selection')

    elif family=='F08':
        gamma,noise={1/6:(2.5,.065),.5:(1.5,.10),5/6:(.75,.15)}[h]
        zn=rng.uniform(-3,3,size=(n_normal,1)); ln=_latent_curve(zn); Xn=_embed_low_dim(ln,d,rng); Xn+=rng.normal(0,noise,size=Xn.shape)
        za=rng.uniform(-3,3,size=(n_anomaly,1)); la=_latent_curve(za); Xa=_embed_low_dim(la,d,rng); direction=sample_unit_vector(d,rng); Xa+=gamma*direction; Xa+=rng.normal(0,noise,size=Xa.shape)
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly)
        m.update(anomaly_type='off_manifold',intrinsic_dim=1,embedding_dim=d,manifold_type='sinusoidal_curve_embedded',manifold_noise=noise,manifold_deviation=gamma,expected_failure='global_detectors_for_local_geometry')

    elif family=='F09':
        margin={1/6:.75,.5:.35,5/6:.125}[h]; R=1.0
        Xn=sample_uniform_inside_ball(n_normal,d,R,rng); directions=sample_unit_vectors(n_anomaly,d,rng); radii=R+margin+rng.normal(0,max(margin/5,1e-4),size=n_anomaly); radii=np.maximum(radii,R+1e-4); Xa=directions*radii[:,None]
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly,extra_id='ball')
        m.update(anomaly_type='near_boundary_violation',boundary_shape='ball',boundary_radius=R,boundary_margin=margin,boundary_difficulty_index=float(1/margin),expected_failure='methods_without_support_boundary_model')

    elif family=='F10':
        pmap={1/6:(2.5,4.25,.85,.65),.5:(3.5,3.25,1.0,.65),5/6:(4.5,2.75,1.2,.55)}
        rare_d,anom_d,rare_s,anom_s=pmap[h]; rare_ratio=.05; nrare=max(1,int(np.floor(rare_ratio*n_normal))); nmain=n_normal-nrare
        Xmain=rng.normal(0,1,size=(nmain,d)); ur=sample_unit_vector(d,rng); ua=sample_unit_vector(d,rng)
        if np.dot(ur,ua)>.8: ua=-ua
        mur=rare_d*ur; mua=anom_d*ua; Xrare=rng.normal(mur,rare_s,size=(nrare,d)); Xa=rng.normal(mua,anom_s,size=(n_anomaly,d)); Xn=np.vstack([Xmain,Xrare])
        name,short=FAMILY_NAMES[family]
        m=make_base_metadata(family_id=family,family_name=name,family_short=short,n_samples=n,n_features=d,contamination=pi,difficulty=diff,seed=seed,n_normal=n_normal,n_anomaly=n_anomaly,extra_id='r05')
        m.update(anomaly_type='rare_normal_vs_true_anomaly',rare_normal_ratio=rare_ratio,n_rare_normal=nrare,n_main_normal=nmain,rare_center=mur,anomaly_center=mua,rare_sigma=rare_s,anomaly_sigma=anom_s,rare_distance=rare_d,anomaly_distance=anom_d,rare_anomaly_distance_ratio=float(rare_d/anom_d),density_inversion=bool(anom_s<rare_s),expected_failure='rarity_equals_anomaly_detectors')
    else:
        raise ValueError(f'Unknown family {family}')

    X,y,m=_finish_dataset(Xn,Xa,m,rng=rng,scale=scale,shuffle=shuffle)
    return X,y,_tag(m,family,h,None)
