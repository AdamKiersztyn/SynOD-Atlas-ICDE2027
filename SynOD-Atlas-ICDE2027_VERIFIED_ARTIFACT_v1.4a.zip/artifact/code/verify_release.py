"""Integrity and optional frozen-table reproduction comparison for ICDE v1.4."""
from pathlib import Path
import argparse,json,sqlite3
import numpy as np,pandas as pd
from pandas.testing import assert_frame_equal
BANNED={'ecod','feod','efrod','rcod','frod'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--artifact-root',default=str(Path(__file__).resolve().parents[1]));ap.add_argument('--reproduced');a=ap.parse_args();p=Path(a.artifact_root)
 m=pd.read_csv(p/'core_metrics.csv');d=pd.read_csv(p/'v21a_datasets_metadata.csv');s=pd.read_csv(p/'sample_size_extension_v11/sample_size_n250_to_10000_all_metrics.csv');h=pd.read_csv(p/'hyperparameter_sensitivity/hyperparam_all_metrics.csv');r=pd.read_csv(p/'real31_detector_profiles.csv')
 assert (len(d),len(m),m.detector.nunique(),len(s),len(h),len(r),len(r.columns)-1)==(2100,27300,13,6552,1008,31,24)
 assert not set(m.detector.str.lower())&BANNED and not set(c.lower() for c in r)&BANNED
 assert not m.duplicated(['dataset_id','detector']).any() and m.groupby('dataset_id').size().eq(13).all()
 assert not s.duplicated(['family','d','n','pi','stress','seed','detector']).any()
 assert s.groupby('n').size().eq(1092).all()
 assert not h.duplicated(['family','stress','seed','method','config']).any()
 for x in [m,s,h]:
  pi_actual=np.maximum(1,np.minimum(x.n-1,np.floor(x.pi*x.n)))/x.n
  q=(np.clip(2*(x.roc_auc-.5),0,1)+np.clip((x.average_precision-pi_actual)/(1-pi_actual+1e-12),0,1))/2
  assert np.isfinite(x.q).all() and np.max(np.abs(q-x.q))<1e-12
 con=sqlite3.connect(p/'failure_cube.sqlite');assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not con.execute('PRAGMA foreign_key_check').fetchall();assert con.execute('SELECT COUNT(*) FROM incomplete_datasets').fetchone()[0]==0
 statements=[x.strip() for x in '\n'.join(line for line in (p/'canonical_queries.sql').read_text().splitlines() if not line.lstrip().startswith('--')).split(';') if x.strip()];query_rows=[len(con.execute(x).fetchall()) for x in statements];assert query_rows[3]==0;con.close()
 report={'datasets':len(d),'runs':len(m),'detectors':13,'sample_size_runs':len(s),'hyperparameter_runs':len(h),'real_panel':[31,24],'canonical_query_rows':query_rows,'status':'PASS'}
 if a.reproduced:
  out=Path(a.reproduced);n=0
  for saved,new in [('reproduced_analysis_v10','analysis'),('reproduced_analysis_v11','sample_size_analysis')]:
   for f in sorted((p/saved).glob('*.csv')):
    x=pd.read_csv(f);y=pd.read_csv(out/new/f.name);assert_frame_equal(x,y,check_exact=False,rtol=1e-9,atol=1e-11);n+=1
  for name in ['hyperparameter_summary.csv','hyperparam_effect_decomposition.csv']:
   assert_frame_equal(pd.read_csv(p/'hyperparameter_sensitivity'/name),pd.read_csv(out/'hyperparameters'/name),check_exact=False,rtol=1e-9,atol=1e-11);n+=1
  report['reproduced_tables_compared']=n
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
