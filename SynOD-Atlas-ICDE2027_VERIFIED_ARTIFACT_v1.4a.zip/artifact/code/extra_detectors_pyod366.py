"""Source-faithful training-score adaptations of five public PyOD 3.6.6 detectors.

Source: yzhao062/pyod tag v3.6.6, target commit
3a71f47bb2cb9b7c8a09fc92e5c67510d7198b58.
Only continuous training anomaly-score logic is retained. PyOD's
contamination-dependent threshold/label post-processing is intentionally omitted
because SynOD-Atlas evaluates raw scores using ROC-AUC and average precision.
"""
from __future__ import annotations
import numpy as np
from scipy.stats import skew as skew_sp
from sklearn.metrics import euclidean_distances, DistanceMetric
from sklearn.utils import check_random_state

EXTRA_DETECTORS=['hbos','copod','loda','inne','sampling']
SOURCE_TAG='PyOD v3.6.6'
SOURCE_COMMIT='3a71f47bb2cb9b7c8a09fc92e5c67510d7198b58'

def column_ecdf(matrix):
    matrix=np.asarray(matrix,float); n,d=matrix.shape
    probabilities=np.linspace(np.ones(d)/n,np.ones(d),n)
    sort_idx=np.argsort(matrix,axis=0)
    sm=np.take_along_axis(matrix,sort_idx,axis=0)
    for cx in range(d):
        for rx in range(n-2,-1,-1):
            if sm[rx,cx]==sm[rx+1,cx]: probabilities[rx,cx]=probabilities[rx+1,cx]
    reordered=np.ones_like(probabilities)
    np.put_along_axis(reordered,sort_idx,probabilities,axis=0)
    return reordered

def hbos_score(X,n_bins=10,alpha=.1,tol=.5):
    X=np.asarray(X,float); n,d=X.shape
    hist=np.zeros((n_bins,d)); edges=np.zeros((n_bins+1,d))
    for i in range(d): hist[:,i],edges[:,i]=np.histogram(X[:,i],bins=n_bins,density=True)
    out=np.zeros((n,d))
    for i in range(d):
        inds=np.digitize(X[:,i],edges[:,i],right=True); s=np.log2(hist[:,i]+alpha)
        for j,b in enumerate(inds):
            if b==0:
                dist=edges[0,i]-X[j,i]; width=edges[1,i]-edges[0,i]; out[j,i]=s[0] if dist<=width*tol else np.min(s)
            elif b==n_bins+1:
                dist=X[j,i]-edges[-1,i]; width=edges[-1,i]-edges[-2,i]; out[j,i]=s[-1] if dist<=width*tol else np.min(s)
            else: out[j,i]=s[b-1]
    return -np.sum(out,axis=1)

def _tail_components(X):
    Ul=-np.log(column_ecdf(X)); Ur=-np.log(column_ecdf(-X)); sk=np.sign(np.nan_to_num(skew_sp(X,axis=0)))
    Usk=Ul * -1*np.sign(sk-1) + Ur*np.sign(sk+1)
    return Ul,Ur,Usk

def copod_score(X):
    Ul,Ur,Usk=_tail_components(np.asarray(X,float)); return np.maximum(Usk,(Ul+Ur)/2).sum(axis=1).ravel()


def loda_score(X,random_state=1,n_bins=10,n_random_cuts=100):
    X=np.asarray(X,float); n,d=X.shape; rng=check_random_state(random_state)
    weights=np.ones(n_random_cuts,float)/n_random_cuts; proj=rng.randn(n_random_cuts,d); n_zero=d-int(np.sqrt(d)); pred=np.zeros(n,float)
    for i in range(n_random_cuts):
        rands=rng.permutation(d)[:n_zero]; proj[i,rands]=0.; z=proj[i,:].dot(X.T)
        h,lim=np.histogram(z,bins=n_bins,density=False); h=h.astype(float)+1e-12; h/=h.sum(); inds=np.searchsorted(lim[:n_bins-1],z,side='left')
        pred += -weights[i]*np.log(h[inds])
    return pred/n_random_cuts

def inne_score(X,random_state=1,n_estimators=200,max_samples='auto'):
    X=np.asarray(X,float); n,d=X.shape; m=min(8,n) if max_samples=='auto' else int(max_samples)
    rs=check_random_state(random_state); seeds=rs.randint(np.iinfo(np.int32).max,size=n_estimators); eps=np.finfo(float).eps; iso=np.ones((n_estimators,n),float)
    for i,sd in enumerate(seeds):
        rnd=check_random_state(sd); idx=rnd.choice(n,m,replace=False); C=X[idx]
        cd=euclidean_distances(C,C,squared=True); np.fill_diagonal(cd,np.inf); radius=np.amin(cd,axis=1); cnn=np.argmin(cd,axis=1); cnn_radius=radius[cnn]
        ratio=1-(cnn_radius+eps)/(radius+eps); xd=euclidean_distances(X,C,squared=True)
        cover=np.where(xd<=radius[None,:],radius[None,:],np.nan); covered=np.where(~np.isnan(cover).all(axis=1))[0]
        if len(covered):
            cnn_x=np.nanargmin(cover[covered],axis=1); iso[i,covered]=ratio[cnn_x]
    return np.mean(iso,axis=0)

def sampling_score(X,random_state=1,subset_size=20):
    X=np.asarray(X,float); n=X.shape[0]; rng=check_random_state(random_state); idx=rng.choice(n,size=min(subset_size,n),replace=False); subset=X[idx]
    dist=DistanceMetric.get_metric('minkowski'); return np.min(dist.pairwise(X,subset),axis=1)

def run_extra_detector(name,X,random_state=1):
    if name=='hbos': return hbos_score(X)
    if name=='copod': return copod_score(X)
    if name=='loda': return loda_score(X,random_state=random_state)
    if name=='inne': return inne_score(X,random_state=random_state)
    if name=='sampling': return sampling_score(X,random_state=random_state)
    raise ValueError(name)
