"""Regenerate the complete 2,100-dataset / 27,300-run SynOD-Atlas v1.0 core."""
from __future__ import annotations
import argparse,time
from pathlib import Path
import numpy as np,pandas as pd
from generators_v21 import generate_v21,STRESSES
from detectors_v21a import DEFAULT_DETECTORS,run_detector_v21a
from extra_detectors_pyod366 import EXTRA_DETECTORS,run_extra_detector
from synod_atlas.evaluation import compute_metrics
FAMILIES=[f'F{i:02d}' for i in range(1,11)]; DS=[10,50,100]; PIS=[.05,.10]; SEEDS=[1,2,3,4,5]
def dsid(f,d,n,pi,h,s): return f'{f}_d{d}_n{n}_pi{int(round(pi*100)):02d}_stress{int(round(h*600)):03d}_seed{s:02d}'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default='v10_core');ap.add_argument('--n',type=int,default=500);a=ap.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 mrows=[];rrows=[];dets=list(DEFAULT_DETECTORS)+list(EXTRA_DETECTORS);t0=time.time()
 for fam in FAMILIES:
  for d in DS:
   for pi in PIS:
    for h in STRESSES:
     for seed in SEEDS:
      X,y,m=generate_v21(fam,a.n,d,pi,h,seed); did=dsid(fam,d,a.n,pi,h,seed); mm=dict(m);mm['dataset_id']=did;mrows.append(mm)
      for det in dets:
       st=time.perf_counter();err='';status='ok'
       try:
        scores=run_detector_v21a(det,X,random_state=seed).scores if det in DEFAULT_DETECTORS else np.asarray(run_extra_detector(det,X,random_state=seed),float)
        z=compute_metrics(y,scores)
       except Exception as e:
        status='error';err=repr(e);z={'roc_auc':np.nan,'average_precision':np.nan,'rank_quality':np.nan}
       rrows.append(dict(dataset_id=did,family=fam,d=d,n=a.n,pi=pi,stress=h,seed=seed,detector=det,status=status,runtime_sec=time.perf_counter()-st,error=err,roc_auc=z['roc_auc'],average_precision=z['average_precision'],q=z['rank_quality']))
  pd.DataFrame(rrows).to_csv(out/'metrics_checkpoint.csv',index=False)
  print(f'{fam}: runs={len(rrows)} errors={sum(r["status"]!="ok" for r in rrows)} elapsed={time.time()-t0:.1f}s',flush=True)
 pd.DataFrame(mrows).to_csv(out/'datasets_metadata.csv',index=False);pd.DataFrame(rrows).to_csv(out/'metrics.csv',index=False)
 print(f'datasets={len(mrows)} runs={len(rrows)} errors={sum(r["status"]!="ok" for r in rrows)}')
if __name__=='__main__':main()
