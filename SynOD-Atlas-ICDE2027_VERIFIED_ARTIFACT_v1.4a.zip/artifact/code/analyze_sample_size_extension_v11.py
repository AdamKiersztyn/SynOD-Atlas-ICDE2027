from __future__ import annotations
import argparse,itertools
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import spearmanr
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

FORM='q ~ C(detector)+C(family)+C(stress)+C(detector):C(family)+C(detector):C(stress)+C(family):C(stress)'

def effects(g):
    cell=g.groupby(['family','stress','detector'],as_index=False).q.mean()
    mod=smf.ols(FORM,cell).fit();a=anova_lm(mod,typ=2);res=float(a.loc['Residual','sum_sq'])
    eta=lambda k:float(a.loc[k,'sum_sq']/(a.loc[k,'sum_sq']+res))
    ef=eta('C(family)');ed=eta('C(detector)');ei=eta('C(detector):C(family)')
    return cell,dict(n=int(g.n.iloc[0]),adjusted_r2=mod.rsquared_adj,eta_family=ef,eta_detector=ed,eta_detector_x_family=ei,interaction_to_detector_ratio=ei/ed)

def morph(g,tau=.30):
    cp=(g.assign(comp=g.q.ge(tau)).groupby(['family','detector','stress'],as_index=False).comp.mean())
    rows=[]
    for (fam,det),x in cp.groupby(['family','detector']):
        x=x.sort_values('stress');curve=x.comp.to_numpy();b=(curve>=.5).astype(int);comps=int(np.sum((b==1)&(np.r_[0,b[:-1]]==0)))
        if b.sum()==0: typ='never_competent'
        elif b.sum()==len(b): typ='always_competent'
        elif b[0]==1 and comps==1: typ='collapse'
        elif b[-1]==1 and comps==1: typ='emergence'
        elif comps>=2: typ='competence_island'
        else: typ='partial'
        rows.append([fam,det,typ,b.mean(),curve.mean()])
    return pd.DataFrame(rows,columns=['family','detector','morphology','competence_volume','mean_competence_probability'])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--metrics',required=True)
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(a.metrics);df=df[df.status.eq('ok')].copy()
    cells={};profs={};ers=[]
    for n,g in df.groupby('n'):
        c,e=effects(g);cells[int(n)]=c;profs[int(n)]=morph(g);ers.append(e)
    effects_df=pd.DataFrame(ers).sort_values('n');effects_df.to_csv(out/'sample_size_effects_extended.csv',index=False)
    surf=[];detord=[];morphrows=[];ns=sorted(cells)
    for a0,b0 in itertools.combinations(ns,2):
        A=cells[a0].sort_values(['family','stress','detector']);B=cells[b0].sort_values(['family','stress','detector'])
        assert (A[['family','stress','detector']].to_numpy()==B[['family','stress','detector']].to_numpy()).all()
        surf.append([a0,b0,spearmanr(A.q,B.q).statistic,float(np.mean(np.abs(A.q-B.q)))])
        ma=A.groupby('detector').q.mean().sort_index();mb=B.groupby('detector').q.mean().sort_index();detord.append([a0,b0,spearmanr(ma,mb).statistic])
        P=profs[a0].sort_values(['family','detector']).reset_index(drop=True);Q=profs[b0].sort_values(['family','detector']).reset_index(drop=True)
        morphrows.append([a0,b0,float((P.morphology==Q.morphology).mean()),spearmanr(P.competence_volume,Q.competence_volume).statistic,spearmanr(P.mean_competence_probability,Q.mean_competence_probability).statistic])
    pd.DataFrame(surf,columns=['n_a','n_b','cell_q_spearman','cell_q_mae']).to_csv(out/'sample_size_surface_stability_extended.csv',index=False)
    pd.DataFrame(detord,columns=['n_a','n_b','detector_mean_order_spearman']).to_csv(out/'sample_size_detector_order_extended.csv',index=False)
    pd.DataFrame(morphrows,columns=['n_a','n_b','morphology_exact_agreement','competence_volume_spearman','mean_competence_probability_spearman']).to_csv(out/'sample_size_morphology_extended.csv',index=False)
    for n,p in profs.items(): p.assign(n=n).to_csv(out/f'morphology_n{n}.csv',index=False)

if __name__=='__main__': main()
