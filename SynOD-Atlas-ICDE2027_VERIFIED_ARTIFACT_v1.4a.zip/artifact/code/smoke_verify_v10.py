"""Deterministic smoke check for all 13 active ICDE v1.4 detectors."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np,pandas as pd
from generators_v21 import generate_v21
from detectors_v21a import DEFAULT_DETECTORS,run_detector_v21a
from extra_detectors_pyod366 import EXTRA_DETECTORS,run_extra_detector
from synod_atlas.evaluation import compute_metrics
CASES=[('F01',10,.05,0.0,1),('F03',50,.10,.5,2),('F06',100,.05,5/6,3),('F09',50,.10,1.0,4),('F10',10,.05,2/3,5)]
def did(f,d,pi,h,s): return f'{f}_d{d}_n500_pi{int(round(pi*100)):02d}_stress{int(round(h*600)):03d}_seed{s:02d}'
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--artifact-root',default=str(Path(__file__).resolve().parents[1])); a=ap.parse_args(); root=Path(a.artifact_root); frozen=pd.read_csv(root/'core_metrics.csv').set_index(['dataset_id','detector']); rows=[]
 for fam,d,pi,h,seed in CASES:
  X,y,_=generate_v21(fam,500,d,pi,h,seed); ds=did(fam,d,pi,h,seed)
  for det in list(DEFAULT_DETECTORS)+list(EXTRA_DETECTORS):
   scores=run_detector_v21a(det,X,random_state=seed).scores if det in DEFAULT_DETECTORS else run_extra_detector(det,X,random_state=seed)
   z=compute_metrics(y,scores); t=frozen.loc[(ds,det)]
   rows.append([ds,det,abs(z['roc_auc']-t.roc_auc),abs(z['average_precision']-t.average_precision),abs(z['rank_quality']-t.q)])
 D=pd.DataFrame(rows,columns=['dataset_id','detector','auc_diff','ap_diff','q_diff']); mx=D[['auc_diff','ap_diff','q_diff']].max(); print(mx.to_string()); print(f'checked={len(D)}')
 if D[['auc_diff','ap_diff','q_diff']].to_numpy().max()>1e-12: raise SystemExit('verification failed')
if __name__=='__main__': main()
