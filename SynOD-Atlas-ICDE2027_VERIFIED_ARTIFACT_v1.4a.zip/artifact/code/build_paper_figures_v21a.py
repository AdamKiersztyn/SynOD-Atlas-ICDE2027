"""Regenerate the six principal figures in the SynOD-Atlas ICDE manuscript.

The plotting code is intentionally the single source for the PNGs bundled with the
paper. Re-running this file from the frozen release tables must reproduce the
manuscript figures byte-for-byte under the frozen environment.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Order reflects detector principles used in the manuscript rather than alphabetical order.
DETS=['knn','avg_knn','lof','iforest','pca','ocsvm','kmeans','gmm','hbos','copod','loda','inne','sampling']
FAMS=[f'F{i:02d}' for i in range(1,11)]
MORPH_CODE={
    'collapse':'C',
    'always_competent':'A',
    'never_competent':'N',
    'emergence':'E',
    'competence_island':'I',
    'partial':'P',
}


def _dominant_or_mixed(s: pd.Series) -> str:
    vc=s.value_counts()
    if len(vc)==0:
        return 'M'
    # A morphology is called dominant only when it occupies a strict majority of
    # the six (dimension, contamination) contexts. Otherwise retain heterogeneity.
    if float(vc.iloc[0]) / float(len(s)) <= 0.5:
        return 'M'
    return MORPH_CODE.get(vc.index[0], 'M')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--metrics',required=True)
    ap.add_argument('--analysis',required=True)
    ap.add_argument('--real',required=True)
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    m=pd.read_csv(a.metrics); A=Path(a.analysis)

    # 1. Geometry gap: aggregate proximity vs surface proximity.
    g=pd.read_csv(A/'detector_pair_geometry_q.csv')
    fig,ax=plt.subplots(figsize=(7.4,4.8))
    ax.scatter(g.abs_mean_gap,g.morphology_rmse,s=46,alpha=.82)
    for x,y,label in zip(g.abs_mean_gap,g.morphology_rmse,g.detector_a+'-'+g.detector_b):
        if label in {'kmeans-ocsvm','avg_knn-knn','loda-lof','loda-lof'}:
            ax.annotate(label,(x,y),xytext=(6,6),textcoords='offset points',fontsize=7)
    ax.set_xlabel('Absolute gap in global mean quality')
    ax.set_ylabel('Standardized response-surface distance (RMSE)')
    ax.set_title('Aggregate proximity does not imply geometric proximity')
    ax.grid(alpha=.22)
    fig.tight_layout();fig.savefig(out/'fig_geometry_gap.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # 2. Morphology counts.
    c=pd.read_csv(A/'morphology_counts_tau030.csv').sort_values('n_profiles')
    labels={
        'never_competent':'Never competent','always_competent':'Always competent',
        'competence_island':'Competence island','collapse':'Collapse',
        'emergence':'Emergence','partial':'Partial'
    }
    fig,ax=plt.subplots(figsize=(7.2,4.6))
    bars=ax.barh([labels.get(x,x) for x in c.morphology],c.n_profiles)
    ax.set_xlabel('Number of detector-context profiles')
    ax.set_title('Failure is not a single transition type')
    ax.grid(axis='x',alpha=.22)
    ax.set_xlim(0,float(c.n_profiles.max())*1.13)
    for b,v in zip(bars,c.n_profiles):
        ax.text(v+3,b.get_y()+b.get_height()/2,str(int(v)),va='center',fontsize=9)
    fig.tight_layout();fig.savefig(out/'fig_competence_morphology_counts.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # 3. Family stress trajectories.
    t=m.groupby(['family','stress'],as_index=False).q.mean()
    fig,ax=plt.subplots(figsize=(8.4,5.0))
    for fam,gp in t.groupby('family'):
        ax.plot(gp.stress,gp.q,marker='o',ms=3,label=fam)
    ax.set_xlabel('Mechanism-specific structural stress')
    ax.set_ylabel('Mean normalized quality q')
    ax.set_title('Mechanism-specific stress trajectories in lineage-preserving v2.1a')
    ax.grid(alpha=.22);ax.legend(ncol=5,fontsize=7,frameon=False)
    fig.tight_layout();fig.savefig(out/'fig_family_stress_trajectories.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # 4. Failure atlas: competence volume plus strict-majority morphology.
    prof=pd.read_csv(A/'profile_morphology_tau030.csv')
    bd=pd.read_csv(A/'boundary_bootstrap_tau030.csv')
    heat=(prof.groupby(['family','detector']).competence_volume.mean().unstack()
          .reindex(index=FAMS,columns=DETS))
    dom=(prof.groupby(['family','detector']).morphology.agg(_dominant_or_mixed).unstack()
         .reindex(index=FAMS,columns=DETS))
    # Median point boundary only among contexts classified as collapse.
    coll=prof[prof.morphology=='collapse'][['family','d','pi','detector']]
    coll=coll.merge(bd[['family','d','pi','detector','boundary50_point']],
                    on=['family','d','pi','detector'],how='left')
    medb=(coll.groupby(['family','detector']).boundary50_point.median().unstack()
          .reindex(index=FAMS,columns=DETS))

    fig,ax=plt.subplots(figsize=(8.4,4.8))
    im=ax.imshow(heat.values,aspect='auto',vmin=0,vmax=1)
    ax.set_xticks(range(len(DETS)),DETS,rotation=35,ha='right')
    ax.set_yticks(range(len(FAMS)),FAMS)
    ax.set_xlabel('Detector');ax.set_ylabel('Mechanism')
    ax.set_title('Failure Atlas: coverage and dominant competence morphology (tau=0.30)')
    cb=fig.colorbar(im,ax=ax);cb.set_label('Mean competence volume')
    for i,fam in enumerate(FAMS):
        for j,det in enumerate(DETS):
            code=dom.iloc[i,j]
            if code=='C' and pd.notna(medb.iloc[i,j]):
                txt=f'C {medb.iloc[i,j]:.2f}'
            else:
                txt=str(code)
            ax.text(j,i,txt,ha='center',va='center',fontsize=8, color='white' if heat.iloc[i,j]<.45 else '#111111')
    fig.tight_layout();fig.savefig(out/'fig_failure_atlas.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # 5. Boundary uncertainty. Use the same point-boundary definition reported in text.
    b=pd.read_csv(A/'boundary_bootstrap_tau030.csv')
    z=b[b.boundary50_point.notna()].groupby('family').ci_width.median().reindex(FAMS)
    fig,ax=plt.subplots(figsize=(7.2,4.3))
    ax.bar(z.index,z.values)
    ax.set_xlabel('Mechanism');ax.set_ylabel('Median 95% bootstrap CI width')
    ax.set_title('Transition localization is mechanism-dependent')
    ax.grid(axis='y',alpha=.22)
    fig.tight_layout();fig.savefig(out/'fig_boundary_uncertainty_by_family.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # 6. Real-panel analogue of the mean-vs-profile geometry distinction.
    r=pd.read_csv(A/'real25_pairwise_profile_geometry.csv')
    fig,ax=plt.subplots(figsize=(7.2,4.5))
    ax.scatter(r.abs_mean_gap,1-r.profile_spearman,s=30,alpha=.72)
    for _,row in r.nsmallest(12,'abs_mean_gap').iterrows():
        lab=f"{row.detector_a}-{row.detector_b}"
        if lab in {'COF-KPCA','SOD-LODA','KNN-IQR','KNN-ModZScore'}:
            ax.annotate(lab,(row.abs_mean_gap,1-row.profile_spearman),xytext=(4,4),textcoords='offset points',fontsize=7)
    ax.axvline(.015,ls='--',lw=1)
    ax.set_xlabel('Absolute gap in real-panel mean quality')
    ax.set_ylabel('Dataset-wise rank divergence (1 - Spearman)')
    ax.set_title('Real data: similar means can hide different response profiles')
    ax.grid(alpha=.22)
    fig.tight_layout();fig.savefig(out/'fig_real25_mean_vs_morphology.png',dpi=300,bbox_inches='tight');plt.close(fig)
    print('wrote',out)

if __name__=='__main__':
    main()
