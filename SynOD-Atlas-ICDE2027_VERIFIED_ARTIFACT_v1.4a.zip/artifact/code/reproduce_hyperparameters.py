"""Reproduce frozen sensitivity summaries; --regenerate reruns 1,008 executions."""
from pathlib import Path
import argparse,time
import numpy as np,pandas as pd
from scipy.stats import spearmanr
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from synod_atlas.detectors import LOFDetector,IsolationForestDetector,OneClassSVMDetector
from detectors_v21a import PCADetectorV21A
from generators_v21 import generate_v21
from synod_atlas.evaluation import compute_metrics
from analyze_sample_size_extension_v11 import morph
FACT={'lof':LOFDetector,'iforest':IsolationForestDetector,'ocsvm':OneClassSVMDetector,'pca':PCADetectorV21A}
DEFAULT={'lof':'k20','iforest':'t100','ocsvm':'nu050','pca':'r20'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--artifact-root',default=str(Path(__file__).resolve().parents[1]));ap.add_argument('--output',required=True);ap.add_argument('--regenerate',action='store_true');a=ap.parse_args();root=Path(a.artifact_root);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 frozen=pd.read_csv(root/'hyperparameter_sensitivity/hyperparam_all_metrics.csv');df=frozen.copy()
 if a.regenerate:
  rows=[]
  for (fam,h,seed),group in frozen.groupby(['family','stress','seed'],sort=False):
   X,y,_=generate_v21(fam,500,50,.05,h,seed)
   for r in group.itertuples():
    value=int(r.value) if r.method!='ocsvm' else r.value
    start=time.perf_counter();scores=FACT[r.method](value).fit_score(X,random_state=seed);m=compute_metrics(y,scores);row=r._asdict();row.pop('Index');row.update(roc_auc=m['roc_auc'],average_precision=m['average_precision'],q=m['rank_quality'],runtime_sec=time.perf_counter()-start);rows.append(row)
  df=pd.DataFrame(rows);df.to_csv(out/'regenerated_hyperparameters.csv',index=False)
  keys=['family','stress','seed','method','config'];j=df.merge(frozen,on=keys,suffixes=('_new','_ref'),validate='one_to_one');diff=max(float((j[k+'_new']-j[k+'_ref']).abs().max()) for k in ['roc_auc','average_precision','q']);print(f'Raw regeneration: {len(j)} checks; max metric difference={diff:.17g}',flush=True);assert len(j)==1008 and diff<1e-12
 cells=df.groupby(['method','config','family','stress'],as_index=False).q.mean();rows=[];ers=[]
 for method,g in cells.groupby('method'):
  base=g[g.config.eq(DEFAULT[method])].sort_values(['family','stress'])
  for config,c in g.groupby('config'):
   c=c.sort_values(['family','stress']);raw=df[(df.method==method)&(df.config==config)].assign(detector=method);ref=df[(df.method==method)&(df.config==DEFAULT[method])].assign(detector=method);mp=morph(raw).sort_values('family');mr=morph(ref).sort_values('family')
   rows.append(dict(method=method,config=config,is_default=config==DEFAULT[method],surface_spearman=spearmanr(c.q,base.q).statistic,surface_mae=np.abs(c.q.to_numpy()-base.q.to_numpy()).mean(),morphology_exact_agreement=(mp.morphology.to_numpy()==mr.morphology.to_numpy()).mean(),competence_volume_spearman=spearmanr(mp.competence_volume,mr.competence_volume).statistic,mean_q=c.q.mean()))
  mod=smf.ols('q ~ C(config)+C(family)+C(stress)+C(config):C(family)+C(family):C(stress)',g).fit();tab=anova_lm(mod,typ=2);res=tab.loc['Residual','sum_sq'];eta=lambda k:tab.loc[k,'sum_sq']/(tab.loc[k,'sum_sq']+res)
  ers.append(dict(method=method,adjusted_r2=mod.rsquared_adj,eta_family=eta('C(family)'),eta_config=eta('C(config)'),eta_config_x_family=eta('C(config):C(family)'),family_to_config_ratio=eta('C(family)')/eta('C(config)')))
 pd.DataFrame(rows).to_csv(out/'hyperparameter_summary.csv',index=False);pd.DataFrame(ers).to_csv(out/'hyperparam_effect_decomposition.csv',index=False);print('Hyperparameter summaries reproduced.')
if __name__=='__main__':main()
