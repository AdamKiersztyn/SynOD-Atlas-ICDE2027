# Hyperparameter sensitivity audit

Design: 7 mechanisms × 4 stress levels × 3 seeds, n=500, d=50, pi=.05. Four representative detector families; three settings each.

## Per-setting robustness versus the audited default
| method   | config   | is_default   |   surface_spearman |   surface_mae |   morphology_exact_agreement |   competence_volume_spearman |   mean_q |
|:---------|:---------|:-------------|-------------------:|--------------:|-----------------------------:|-----------------------------:|---------:|
| iforest  | t50      | False        |             0.9872 |        0.0288 |                       0.7143 |                       0.9901 |   0.2702 |
| iforest  | t100     | True         |             1.0000 |        0.0000 |                       1.0000 |                       1.0000 |   0.2983 |
| iforest  | t200     | False        |             0.9954 |        0.0179 |                       1.0000 |                       1.0000 |   0.3143 |
| lof      | k10      | False        |             0.9805 |        0.0409 |                       0.8571 |                       0.9806 |   0.3165 |
| lof      | k20      | True         |             1.0000 |        0.0000 |                       1.0000 |                       1.0000 |   0.3572 |
| lof      | k40      | False        |             0.9937 |        0.0327 |                       1.0000 |                       1.0000 |   0.3896 |
| ocsvm    | nu025    | False        |             0.9736 |        0.0167 |                       1.0000 |                       0.9903 |   0.2026 |
| ocsvm    | nu050    | True         |             1.0000 |        0.0000 |                       1.0000 |                       1.0000 |   0.2151 |
| ocsvm    | nu100    | False        |             0.9765 |        0.0783 |                       1.0000 |                       1.0000 |   0.2916 |
| pca      | r10      | False        |             0.9829 |        0.0354 |                       1.0000 |                       1.0000 |   0.1994 |
| pca      | r20      | True         |             1.0000 |        0.0000 |                       1.0000 |                       1.0000 |   0.1719 |
| pca      | r30      | False        |             0.9492 |        0.0441 |                       0.8571 |                       0.5406 |   0.1395 |

## Worst non-default deviation by method
| method   |   min_surface_spearman |   max_surface_mae |   min_morphology_agreement |   min_competence_volume_spearman |
|:---------|-----------------------:|------------------:|---------------------------:|---------------------------------:|
| iforest  |                 0.9872 |            0.0288 |                     0.7143 |                           0.9901 |
| lof      |                 0.9805 |            0.0409 |                     0.8571 |                           0.9806 |
| ocsvm    |                 0.9736 |            0.0783 |                     1.0000 |                           0.9903 |
| pca      |                 0.9492 |            0.0441 |                     0.8571 |                           0.5406 |